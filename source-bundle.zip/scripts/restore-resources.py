"""Restore pinned files from official origins and verify the entire tested site."""
from pathlib import Path
import hashlib
import io
import json
import tarfile
import time
import urllib.request

ROOT=Path(__file__).resolve().parents[1]
SITE=ROOT/'site'
spec=json.loads((ROOT/'resources.json').read_text('utf-8'))
archives={}

def fetch(url):
    for attempt in range(3):
        try:
            request=urllib.request.Request(url,headers={'User-Agent':'ListenLab-static-build/1.0'})
            with urllib.request.urlopen(request,timeout=180) as response:return response.read()
        except Exception:
            if attempt==2:raise
            time.sleep(2*(attempt+1))

for resource in spec['resources']:
    path=(SITE/resource['file']).resolve()
    if not path.is_relative_to(SITE.resolve()):raise ValueError('Invalid resource path')
    if path.exists() and hashlib.sha256(path.read_bytes()).hexdigest()==resource['sha256']:
        print('Verified existing '+resource['file'],flush=True);continue
    url=resource['source']
    if 'member' in resource:
        if url not in archives:archives[url]=fetch(url)
        with tarfile.open(fileobj=io.BytesIO(archives[url]),mode='r:gz') as archive:
            data=archive.extractfile(resource['member']).read()
    else:data=fetch(url)
    if len(data)!=resource['bytes'] or hashlib.sha256(data).hexdigest()!=resource['sha256']:
        raise ValueError('Resource does not match the tested version: '+resource['file'])
    path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
    print('Restored and verified '+resource['file'],flush=True)

for name,expected in spec['siteHashes'].items():
    path=SITE/name
    if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
        raise ValueError('Site file does not match tested release: '+name)
print(f"PASS: all {len(spec['siteHashes'])} deployed files match the locally tested release.",flush=True)
