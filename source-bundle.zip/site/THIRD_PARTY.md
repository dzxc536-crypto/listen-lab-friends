# 第三方资源

本项目调用已准备的本地环境，并把浏览器运行资源固定版本保存。没有使用付费字体或云端识别接口。

| 资源 | 版本 / 来源 | 许可记录 |
|---|---|---|
| faster-whisper | 1.2.1，[官方仓库](https://github.com/SYSTRAN/faster-whisper) | MIT；调用共享本地环境 |
| WhisperX | 3.8.6，[官方仓库](https://github.com/m-bain/whisperX) | BSD-2-Clause；调用共享本地环境 |
| FFmpeg | 本地 7.1.1 full shared 构建，[构建来源](https://github.com/GyanD/codexffmpeg/releases/tag/7.1.1) | 调用已安装构建，不打包进手机前端；依构建启用项保留其许可要求 |
| Transformers.js | 3.8.1，[官方仓库](https://github.com/huggingface/transformers.js) | Apache-2.0；`vendor/huggingface-transformers-LICENSE.txt` |
| ONNX Runtime Web | 1.22.0-dev.20250409-89f8206ba4，[官方仓库](https://github.com/microsoft/onnxruntime) | MIT；`vendor/onnxruntime-LICENSE.txt`；保留官方第三方声明 |
| Whisper ONNX tiny.en | [Xenova/whisper-tiny.en](https://huggingface.co/Xenova/whisper-tiny.en)，提交 `79fb389fc764e7c395bd330e9531d9d32ada7049` | 模型卡标注 Apache-2.0，模型卡随包保存 |
| Wav2Vec2 ONNX 英文模型 | [Xenova/wav2vec2-base-960h](https://huggingface.co/Xenova/wav2vec2-base-960h)，提交 `a19f851b3d42865797e410752b4c570c871e4825` | 源自 [facebook/wav2vec2-base-960h](https://huggingface.co/facebook/wav2vec2-base-960h)，保留 ONNX 模型卡和原模型卡 |
| 页面字体 | 系统 Segoe UI、Arial、Microsoft YaHei 及系统回退 | 不分发字体文件 |
| 演示音频 | 已有本机 Microsoft Zira 合成短句 | 明确标为合成演示，不作用户音频或性能基准 |

浏览器所用代码、WASM 和模型资源的下载 URL、提交及 SHA-256 存于 `offline-assets.json`。

2026-10-03 歌词保调版使用 SoundTouchJS audio-worklet 2.1.1 处理浏览器材料的 0.1–0.4 倍播放区间，许可为 MPL-2.0；代码与原始许可保留在 `vendor/soundtouch/`，上游来源为 https://github.com/cutterbl/SoundTouchJS 。电脑材料的极慢速区间由 FFmpeg atempo 处理；0.5–2.5 倍使用原生音频保持音调。此次验证见 `verification/user-updates-acceptance.json`，不以旧的 SoundTouch 检查替代本版验收。

2026-10-03 双语版使用 [Xenova/opus-mt-en-zh](https://huggingface.co/Xenova/opus-mt-en-zh) 的 ONNX 量化资源，固定提交 `046f55aec303cdee3e0318604406d4df20f1e8ea`，原模型为 [Helsinki-NLP/opus-mt-en-zh](https://huggingface.co/Helsinki-NLP/opus-mt-en-zh)，原模型卡标注 Apache-2.0。ONNX 模型卡、原模型卡及 Apache-2.0 许可随包保留；下载来源、文件大小及 SHA-256 写入 `offline-assets.json`。本模型目标语言标记使用 `>>cmn_Hans<<`，采用逐句本地推理。机器译文可人工校正，本次合成演示/少量句子不代表真实四级材料的翻译准确率。
