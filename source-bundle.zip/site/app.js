import {getOfflineState,prepareResources,ensureRegistration} from './share-resources.js';
import {Player} from './player.js';
import {prepareLyrics,paintLyrics} from './lyrics.js';
import {pitchClip} from './pitch-clip.js';
import {zipFiles,safeFileName} from './zip.js';
import {listLocal,getLocal,putLocal,deleteLocal,restoreLocal,decodeAudio,wavClip,validateSentences,parseSubtitles,backupBlob,readBackup} from './storage.js';
const $=s=>document.querySelector(s),all=s=>[...document.querySelectorAll(s)];
const time=(s,decimals=false)=>{s=Math.max(0,s||0);return `${Math.floor(s/60).toString().padStart(2,'0')}:${(decimals?(s%60).toFixed(2):Math.floor(s%60).toString()).padStart(decimals?5:2,'0')}`;};
const icon=name=>{const el=document.createElementNS('http://www.w3.org/2000/svg','svg'),use=document.createElementNS('http://www.w3.org/2000/svg','use');use.setAttribute('href','#i-'+name);el.append(use);return el;};
const element=(tag,className,text)=>{const el=document.createElement(tag);if(className)el.className=className;if(text!==undefined)el.textContent=text;return el;};
const prefs=JSON.parse(localStorage.getItem('listen-share-prefs')||'{}');
let token=new URLSearchParams(location.search).get('share')||sessionStorage.getItem('listen-share')||'';
if(token)sessionStorage.setItem('listen-share',token);
let server=null,material=null,current=0,follow=true,loop=false,mask='none',revealed=new Set(),busy=false,editIndex=0,worker,workerTasks=new Map(),saveQueue=Promise.resolve(),lastSave=0,toastTimer,ignoreScrollUntil=0,jobMaterial=null,selecting=0;
const mobile=/Android|iPhone|iPad/i.test(navigator.userAgent);
let engine='browser';
let libraryEntries=[],audioBatchMode=false,exportEntries=null;
const selectedAudio=new Set(),audioKey=m=>(m.kind==='server'?'server':'local')+':'+m.id;
let lastDeleted=[];
try{const saved=JSON.parse(localStorage.getItem('listen-share-delete-undo')||'[]');if(Array.isArray(saved))lastDeleted=saved.filter(m=>typeof m.id==='string'&&['local','server'].includes(m.kind));}catch{}
const lyricPrefs={enabled:prefs.lyricsEnabled!==false,color:/^#[a-f\d]{6}$/i.test(prefs.lyricColor||'')?prefs.lyricColor:'#5267de',wordHighlight:prefs.wordHighlight!==false};
let showTranslation=prefs.translationEnabled===true,translationWorker=null,translationRun=0;

function translationStatus(label){$('#translation-state').textContent=label;$('#translation-summary').hidden=!showTranslation;$('#translation-summary').textContent=translationWorker?label:'中文译文';$('#translation-generate').disabled=!!translationWorker||!material?.sentences.length||busy;}
function cancelTranslation(){translationRun++;translationWorker?.terminate();translationWorker=null;translationStatus(showTranslation?'译文已开启':'译文已关闭');}
function generateTranslation(){
  if(!showTranslation||!material?.sentences.length||translationWorker||busy)return;
  const target=material,entries=target.sentences.map((s,index)=>({index,text:s.text})).filter(e=>!target.sentences[e.index].translation);
  if(!entries.length){translationStatus('本材料译文已保存，可在句子校正中修改。');return;}
  const run=++translationRun,w=new Worker('./translation-worker.js',{type:'module'});translationWorker=w;translationStatus('正在准备本地翻译…');
  const stop=label=>{if(run!==translationRun)return;w.terminate();translationWorker=null;translationStatus(label);};
  w.onmessage=async({data})=>{
    if(run!==translationRun||target!==material)return;
    if(data.type==='status')translationStatus(data.label);
    if(data.type==='sentence'){
      const s=target.sentences[data.index];
      if(s?.text===data.text&&!s.translation){s.translation=data.translation;renderSentences();await protect(saveMaterial)();}
    }
    if(data.type==='done'){try{await saveQueue;stop('译文已生成并保存，可在句子校正中修改。');}catch{stop('译文已生成，但保存失败，请重试保存。');}}
    if(data.type==='error'){stop('翻译失败，可点击“生成缺失译文”重试，或手动填写。');toast('本地翻译未完成：'+data.error);}
  };
  w.onerror=e=>{stop('翻译未完成，请检查本设备的离线资源。');toast('本地翻译模型无法载入：'+(e.message||'请先保存离线资源。'));};
  w.postMessage({entries});
}
function setFontSize(value,persist=true){
  const size=Math.max(12,Math.min(48,Math.round(Number(value)||24)));
  $('#font-size').value=size;$('#font-value').textContent=size+' px';$('#font-quick-value').textContent=size;
  $('#font-decrease').disabled=size===12;$('#font-increase').disabled=size===48;
  document.documentElement.style.setProperty('--subtitle-size',size+'px');
  if(persist)storePrefs();if(material)renderSentences();
}
let densityFrame;
function setSubtitleDensity(value,persist=true){
  const number=Number(value),density=Math.max(0,Math.min(100,Math.round(Number.isFinite(number)?number:80))),fraction=density/100;
  const scroll=$('#transcript-scroll'),top=scroll.getBoundingClientRect().top;
  const anchor=all('#sentences>.sentence').find(row=>row.getBoundingClientRect().bottom>top+1),oldTop=anchor?.getBoundingClientRect().top;
  $('#subtitle-density').value=density;$('#density-number').value=density;
  $('#subtitle-density').setAttribute('aria-valuetext',density+'% 紧凑');
  const style=document.documentElement.style,lerp=(loose,tight)=>loose+(tight-loose)*fraction;
  style.setProperty('--sentence-pad-y',lerp(25,2)+'px');
  style.setProperty('--sentence-gap',lerp(5,0)+'px');
  style.setProperty('--subtitle-leading',lerp(1.65,1.25));
  style.setProperty('--translation-gap',lerp(8,1)+'px');
  style.setProperty('--details-gap',lerp(9,2)+'px');
  style.setProperty('--transcript-pad-top',lerp(12,1)+'px');
  style.setProperty('--transcript-pad-bottom',lerp(34,4)+'px');
  if(anchor)scroll.scrollTop+=anchor.getBoundingClientRect().top-oldTop;
  if(persist)storePrefs();
  cancelAnimationFrame(densityFrame);densityFrame=requestAnimationFrame(()=>{layoutMaskBars();all('.sentence-play').forEach(b=>b._lyricSegments=null);updatePlayback();});
}

async function api(){throw new Error('好友分享版在本设备处理材料，无需电脑后端。');}
function mediaURL(path){return './api/'+path+(path.includes('?')?'&':'?')+'token='+encodeURIComponent(token);}
function toast(text){$('#toast').textContent=text;$('#toast').hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').hidden=true,5500);}
const protect=fn=>async(...args)=>{try{await fn(...args);}catch(e){if(e.name!=='AbortError')toast(e.message||'操作失败，请重试。');}};
function storePrefs(){localStorage.setItem('listen-share-prefs',JSON.stringify({...prefs,engine,font:$('#font-size').value,density:Number($('#subtitle-density').value),theme:$('#theme').value,rate:player.rate,lyricsEnabled:lyricPrefs.enabled,lyricColor:lyricPrefs.color,wordHighlight:lyricPrefs.wordHighlight,translationEnabled:showTranslation}));}
function applyTheme(){const theme=$('#theme').value;document.documentElement.dataset.theme=theme==='system'?(matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light'):theme;}
function sentenceIndex(position){if(!material?.sentences.length)return 0;let index=0;for(let i=0;i<material.sentences.length;i++){if(position>=material.sentences[i].start)index=i;else break;}return index;}
function bounds(){
  const s=material?.sentences[current];
  if(s&&(loop||$('#sentence-mode').checked))return {start:s.start,end:s.end};
  return {start:0,end:material?.duration||0};
}
async function pcm(){
  if(!material)throw new Error('请先导入音频。');
  if(!material.pcm){
    const blob=material.kind==='server'?await (await fetch(mediaURL(`materials/${material.id}/audio`))).blob():material.audio;
    const decoded=await decodeAudio(blob);material.pcm=decoded.pcm;
  }
  return material.pcm;
}
const player=new Player($('#audio'),async(start,end,scale)=>{
  if(material.kind==='server')return mediaURL(`materials/${material.id}/clip?start=${start.toFixed(3)}&end=${end.toFixed(3)}&rate=${scale.toFixed(1)}`);
  return URL.createObjectURL(scale<1?await pitchClip(await pcm(),start,end,scale):wavClip(await pcm(),start,end,1));
},updatePlayback);
player.onEnded=()=>saveProgress(true);

function updatePlayback(){
  const position=player.current();
  $('#seek').value=position;
  $('#time-label').textContent=`${time(position)} / ${time(material?.duration||0)}`;
  $('#play-toggle').classList.toggle('playing',player.playing);$('#play-toggle').setAttribute('aria-label',player.loading?'正在准备播放':player.playing?'暂停':'播放');
  $('#play-toggle').replaceChildren(icon(player.playing?'pause':'play'));
  $('#player-hint').textContent=player.loading?'正在准备保持音调的播放区间…':'0.1–2.5 倍速 · 保持音调';
  if(material?.sentences.length){
    const selected=material.sentences[current];
    const holdSentence=(loop||$('#sentence-mode').checked)&&player.ready&&Math.abs(player.end-selected.end)<.015&&position>=selected.start-.005&&position<=selected.end+.015;
    const idx=holdSentence?current:sentenceIndex(position);
    if(idx!==current&&!player.loading&&!selecting){current=idx;renderSentences();if(follow)scrollCurrent();}
    $('#current-label').textContent=`正在练习第 ${current+1} 句`;
    $('#sentence-position').textContent=`${current+1} / ${material.sentences.length}`;
    $('#prev-sentence').disabled=current===0;$('#next-sentence').disabled=current>=material.sentences.length-1;
    const sentence=material.sentences[current];
    if(lyricPrefs.enabled&&!isMasked(current))paintLyrics($(`#sentence-${current} .sentence-play`),Math.max(0,Math.min(1,(position-sentence.start)/(sentence.end-sentence.start))));
    all('.word.current').forEach(w=>w.classList.remove('current'));
    if(lyricPrefs.wordHighlight&&!isMasked(current)){
      const wordIndex=sentence.words.findIndex(w=>Number.isFinite(w.start)&&position>=w.start&&position<w.end);
      if(wordIndex>=0)$(`#sentence-${current} [data-word="${wordIndex}"]`)?.classList.add('current');
    }
  }else{$('#current-label').textContent=material?'整段音频':'准备开始';$('#sentence-position').textContent='— / —';}
  if(player.playing&&Date.now()-lastSave>5000)saveProgress();
  $('#seek').style.background=`linear-gradient(to right,var(--accent) ${material?position/material.duration*100:0}%,var(--line) 0)`;
}

async function saveMaterial(){
  if(!material)return;
  const snapshot={...material,sentences:structuredClone(material.sentences),progress:player.current()};delete snapshot.pcm;
  $('#save-status').textContent='保存中…';
  saveQueue=saveQueue.catch(()=>{}).then(async()=>{
    if(snapshot.kind==='server')await api(`materials/${snapshot.id}/save`,{method:'POST',body:JSON.stringify({progress:snapshot.progress,sentences:snapshot.sentences})});
    else await putLocal(snapshot);
    $('#save-status').replaceChildren(icon('check'),document.createTextNode('已保存'));
  }).catch(e=>{$('#save-status').textContent='保存失败';toast('材料未保存：'+e.message);throw e;});
  await saveQueue;
}
function saveProgress(force=false){if(!material||busy)return;lastSave=Date.now();material.progress=player.current();saveMaterial().catch(()=>{});}

async function refreshLibrary(){
  let entries=[];
  if(server){try{entries=(await api('materials')).map(m=>({...m,kind:'server'}));}catch{}}
  entries.push(...(await listLocal()).map(m=>({...m,kind:'local'})));
  entries.sort((a,b)=>(b.updated||0)-(a.updated||0));
  libraryEntries=entries;
  const keys=new Set(entries.map(audioKey));for(const key of selectedAudio)if(!keys.has(key))selectedAudio.delete(key);
  renderAudioList();
  $('#library-count').textContent=entries.length;
  const list=$('#library-list');list.replaceChildren();
  if(!entries.length){list.append(element('p','library-empty','练习材料会保存在这里。下次打开，接着上次的位置听。'));syncAudioSelection();return;}
  for(const m of entries){
    const active=material&&audioKey(m)===audioKey(material),row=element('div','library-row'+(active?' active':''));row.dataset.audioKey=audioKey(m);
    row.append(audioCheckbox(m));
    const b=element('button','library-item'+(active?' active':''));b.type='button';b.title=m.name;
    const text=element('span');text.append(element('strong','',m.name),element('small','',`${m.source==='demo'?'演示':m.kind==='server'?'电脑材料':'本设备'} · ${time(m.progress)} / ${time(m.duration)}`));b.append(text);
    b.onclick=protect(()=>activateAudioRow(m));row.append(b,audioDeleteButton(m));list.append(row);
  }
  syncAudioSelection();
}

function audioCheckbox(m){
  const checkbox=element('input','audio-item-check');checkbox.type='checkbox';checkbox.dataset.audioKey=audioKey(m);
  checkbox.setAttribute('aria-label','选择音频 '+m.name);checkbox.checked=selectedAudio.has(audioKey(m));
  checkbox.onchange=()=>{if(checkbox.checked)selectedAudio.add(audioKey(m));else selectedAudio.delete(audioKey(m));syncAudioSelection();};return checkbox;
}
function audioDeleteButton(m){
  const button=element('button','audio-item-delete');button.type='button';button.title='删除音频';button.setAttribute('aria-label','删除音频 '+m.name);button.append(icon('close'));
  button.onclick=protect(()=>deleteAudio([m]));return button;
}
function filteredAudioEntries(){return libraryEntries.filter(m=>m.name.toLocaleLowerCase().includes($('#audio-search').value.trim().toLocaleLowerCase()));}
function syncAudioSelection(){
  document.body.classList.toggle('audio-batch-mode',audioBatchMode);
  all('.audio-item-check').forEach(c=>{c.hidden=!audioBatchMode;c.checked=selectedAudio.has(c.dataset.audioKey);c.disabled=busy;});
  all('.audio-item-delete,.library-item,.audio-list-row').forEach(b=>b.disabled=busy);
  all('.library-row,.audio-list-wrapper').forEach(row=>{
    const checked=audioBatchMode&&selectedAudio.has(row.dataset.audioKey);row.classList.toggle('batch-selected',checked);
    const button=row.querySelector('.library-item,.audio-list-row'),action=row.querySelector('.audio-list-action');
    if(audioBatchMode)button.setAttribute('aria-pressed',String(checked));else button.removeAttribute('aria-pressed');
    if(action)action.textContent=audioBatchMode?(checked?'已选择':'选择'):row.classList.contains('selected')?'正在练习':'打开练习';
  });
  for(const prefix of ['library','audio']){
    $('#'+prefix+'-batch-actions').hidden=!audioBatchMode;
    const toggle=$('#'+prefix+'-batch-toggle');toggle.textContent=audioBatchMode?'完成选择':'批量选择';toggle.setAttribute('aria-expanded',String(audioBatchMode));toggle.disabled=busy||!libraryEntries.length;
    $('#'+prefix+'-selected-count').textContent=`已选 ${selectedAudio.size} 段`;
    $('#'+prefix+'-delete-selected').disabled=$('#'+prefix+'-export-selected').disabled=busy||!selectedAudio.size;
  }
  for(const [selector,entries]of [['#library-select-all',libraryEntries],['#audio-select-all',filteredAudioEntries()]]){
    const checkbox=$(selector),count=entries.filter(m=>selectedAudio.has(audioKey(m))).length;
    checkbox.checked=!!entries.length&&count===entries.length;checkbox.indeterminate=count>0&&count<entries.length;checkbox.disabled=busy||!entries.length;
  }
  $('#export-open').disabled=busy||(!material&&!selectedAudio.size);
  $('#export-open span').textContent=audioBatchMode&&selectedAudio.size?'导出选中':'导出';
  $('#audio-select-all-label').textContent=$('#audio-search').value.trim()?'全选当前结果':'全选';
  for(const id of ['library-undo-delete','audio-undo-delete']){$('#'+id).hidden=!lastDeleted.length;$('#'+id).disabled=busy;}
}
function setAudioBatchMode(enabled){audioBatchMode=enabled;if(!enabled)selectedAudio.clear();syncAudioSelection();}
function selectAudio(entries,checked){for(const m of entries){if(checked)selectedAudio.add(audioKey(m));else selectedAudio.delete(audioKey(m));}syncAudioSelection();}
function activateAudioRow(m){if(busy)throw new Error('请等当前处理完成。');if(audioBatchMode){selectAudio([m],!selectedAudio.has(audioKey(m)));return;}return openLibraryMaterial(m);}
function rememberDeleted(entries){lastDeleted=entries;localStorage.setItem('listen-share-delete-undo',JSON.stringify(entries));syncAudioSelection();}
function clearMaterial(){
  cancelTranslation();material=null;current=0;loop=false;follow=true;revealed.clear();localStorage.removeItem('listen-share-last');
  player.reset(0);if(player.blobURL){URL.revokeObjectURL(player.blobURL);player.blobURL=null;}
  $('#material-title').textContent='从一段英语开始';$('#material-source').textContent='听力练习';$('#material-meta').textContent='准备好耳机，听清每一句';
  $('#sentences').replaceChildren();$('#sentences').hidden=true;$('#empty-state').hidden=false;$('#no-subtitles').hidden=true;
  $('#sentence-count').textContent='暂无字幕';$('#recognition-status').textContent='等待导入';$('#recognition-status').classList.remove('warning');
  $('#realign-all').hidden=$('#return-current').hidden=$('#mask-reset').hidden=true;$('#mask-mode').value=mask='none';
  $('#loop-toggle').setAttribute('aria-pressed','false');$('#follow-toggle').setAttribute('aria-pressed','true');
  for(const id of ['export-open','seek','play-toggle','prev-sentence','next-sentence','loop-toggle'])$('#'+id).disabled=true;
  all('[data-jump]').forEach(b=>b.disabled=true);$('#seek').max=1;
  const waveform=$('#waveform');waveform.getContext('2d').clearRect(0,0,waveform.width,waveform.height);
  $('#alignment-note').textContent='识别结果可校正，时间边界可调整';$('#save-status').textContent='本地保存';
  if('mediaSession'in navigator)navigator.mediaSession.metadata=null;
}
async function changeAudio(entries,restore=false){
  if(busy)throw new Error('请等当前处理完成。');if(!entries.length)return;
  busy=true;syncAudioSelection();const succeeded=[],errors=[];
  const removingCurrent=!restore&&material&&entries.some(m=>audioKey(m)===audioKey(material));
  try{
    if(removingCurrent){cancelTranslation();player.pause();await saveMaterial();}
    await saveQueue.catch(()=>{});
    for(const kind of ['server','local']){
      const group=entries.filter(m=>(m.kind==='server'?'server':'local')===kind);if(!group.length)continue;
      try{
        let ids;
        if(kind==='server'){
          const result=await api('materials/'+(restore?'restore':'delete'),{method:'POST',body:JSON.stringify({ids:group.map(m=>m.id)})});
          ids=result.ids;errors.push(...(result.errors||[]).map(e=>e.error));
        }else ids=await(restore?restoreLocal:deleteLocal)(group.map(m=>m.id));
        succeeded.push(...group.filter(m=>ids.includes(m.id)));
      }catch(error){errors.push(error.message);}
    }
    if(!restore&&succeeded.length){
      for(const m of succeeded)selectedAudio.delete(audioKey(m));
      rememberDeleted(succeeded.map(m=>({id:m.id,kind:m.kind==='server'?'server':'local',name:m.name})));
      if(material&&succeeded.some(m=>audioKey(m)===audioKey(material)))clearMaterial();
    }
    if(restore)rememberDeleted(lastDeleted.filter(m=>!succeeded.some(s=>audioKey(s)===audioKey(m))));
    await refreshLibrary();if(!libraryEntries.length)setAudioBatchMode(false);
    toast((succeeded.length?`已${restore?'恢复':'删除'} ${succeeded.length} 段音频。${restore?'':'可点击“撤销删除”恢复。'}`:'没有音频被'+(restore?'恢复':'删除')+'。')+(errors.length?' 部分操作失败：'+errors.join('；'):''));
  }finally{busy=false;syncAudioSelection();generateTranslation();}
}
const deleteAudio=entries=>changeAudio(entries,false),undoDeleteAudio=()=>changeAudio(lastDeleted,true);

async function openLibraryMaterial(m){
  if(busy)throw new Error('请等当前识别或导入完成。');
  player.pause();await saveMaterial();
  const chosen=m.kind==='server'?{...(await api('materials/'+m.id)),kind:'server'}:await getLocal(m.id);
  if(!chosen)throw new Error('这段音频已删除，请刷新列表。');await loadMaterial(chosen);
  $('#audio-library-dialog').close();
}
function renderAudioList(){
  const query=$('#audio-search').value.trim().toLocaleLowerCase(),sort=$('#audio-sort').value;
  const filtered=filteredAudioEntries();
  filtered.sort(sort==='name'?(a,b)=>a.name.localeCompare(b.name,'zh'):sort==='duration'?(a,b)=>b.duration-a.duration:(a,b)=>(b.updated||0)-(a.updated||0));
  $('#audio-list-total').textContent=`${filtered.length} / ${libraryEntries.length} 段音频`;
  const list=$('#audio-library-list');list.replaceChildren();
  if(!filtered.length){list.append(element('p','library-empty',query?'没有找到匹配的音频，试试其他关键词。':'还没有音频，点击“导入音频”开始。'));syncAudioSelection();return;}
  for(const m of filtered){
    const active=material&&audioKey(m)===audioKey(material),wrapper=element('div','audio-list-wrapper'+(active?' selected':''));wrapper.dataset.audioKey=audioKey(m);wrapper.append(audioCheckbox(m));
    const row=element('button','audio-list-row'+(active?' selected':''));row.type='button';row.append(icon('headphones'));
    const name=element('span','audio-list-name');name.append(element('strong','',m.name),element('small','',`${m.source==='demo'?'合成语音演示':m.kind==='server'?'电脑材料':'本设备材料'} · ${time(m.duration)} · 已听 ${time(m.progress)}`));
    row.append(name,element('span','audio-list-action',active?'正在练习':'打开练习'));row.onclick=protect(()=>activateAudioRow(m));wrapper.append(row,audioDeleteButton(m));list.append(wrapper);
  }
  syncAudioSelection();
}
function syncLyricSettings(){
  document.documentElement.style.setProperty('--lyric-color',lyricPrefs.color);
  $('#lyrics-enable').checked=lyricPrefs.enabled;$('#lyric-word-highlight').checked=lyricPrefs.wordHighlight;
  $('#lyric-color').value=lyricPrefs.color;$('#lyric-hex').value=lyricPrefs.color.toUpperCase();
  ['r','g','b'].forEach((n,i)=>$('#lyric-'+n).value=parseInt(lyricPrefs.color.slice(1+i*2,3+i*2),16));
  $('#lyric-color-error').textContent='';
  if(material)renderSentences();
}
function setLyricColor(value){lyricPrefs.color=value.toLowerCase();syncLyricSettings();storePrefs();}
async function loadMaterial(m){
  cancelTranslation();
  $('#recognition-error').hidden=true;
  material=m;current=sentenceIndex(m.progress||0);revealed=new Set();loop=false;follow=true;
  $('#library-panel').classList.remove('open');$('#material-title').textContent=m.name.replace(/\.[a-z\d]{2,8}$/i,'');
  $('#material-source').textContent=m.source==='demo'?'演示材料':m.kind==='server'?'电脑本地材料':'本设备材料';
  $('#material-meta').textContent=`${time(m.duration)} · ${m.source==='demo'?'合成英语语音':m.kind==='server'?'本地离线处理':'保存在此浏览器'}`;
  $('#empty-state').hidden=true;$('#no-subtitles').hidden=!!m.sentences.length;$('#sentences').hidden=!m.sentences.length;
  $('#export-open').disabled=false;$('#seek').disabled=false;$('#seek').max=m.duration;$('#play-toggle').disabled=false;all('[data-jump]').forEach(b=>b.disabled=false);
  $('#prev-sentence').disabled=!m.sentences.length;$('#next-sentence').disabled=!m.sentences.length;$('#loop-toggle').disabled=!m.sentences.length;
  $('#loop-toggle').setAttribute('aria-pressed','false');$('#follow-toggle').setAttribute('aria-pressed','true');$('#return-current').hidden=true;
  renderSentences();player.reset(m.duration,m.progress||0);localStorage.setItem('listen-share-last',JSON.stringify({id:m.id,kind:m.kind}));
  await refreshLibrary();
  const samples=await pcm();drawWaveform(samples);if(follow)scrollCurrent();
  translationStatus(showTranslation?'译文已开启':'译文已关闭');generateTranslation();
}

function drawWaveform(samples){
  const c=$('#waveform'),width=Math.max(10,Math.floor(c.clientWidth)),height=36,dpr=devicePixelRatio||1;c.width=width*dpr;c.height=height*dpr;
  const ctx=c.getContext('2d');ctx.scale(dpr,dpr);ctx.clearRect(0,0,width,height);ctx.fillStyle='#b8c1e2';
  const count=Math.floor(width/4),stride=Math.max(1,Math.floor(samples.length/count));
  for(let i=0;i<count;i++){let peak=0;const start=i*stride;for(let j=start;j<Math.min(samples.length,start+stride);j+=Math.max(1,Math.floor(stride/40)))peak=Math.max(peak,Math.abs(samples[j]));const h=Math.max(2,Math.min(height-2,Math.sqrt(peak)*height));ctx.fillRect(i*4,(height-h)/2,2,h);}
}
function isMasked(i){return mask!=='none'&&(mask==='all'||i===current)&&!revealed.has(i);}
function layoutMaskBars(){all('.masked-wrapper').forEach(wrapper=>{const layout=wrapper.querySelector('.mask-layout'),range=document.createRange(),walker=document.createTreeWalker(layout,NodeFilter.SHOW_TEXT);const base=wrapper.getBoundingClientRect(),bars=wrapper.querySelector('.mask-bars');bars.replaceChildren();while(walker.nextNode()){range.selectNodeContents(walker.currentNode);for(const rect of range.getClientRects()){const bar=element('i');bar.style.cssText=`left:${rect.left-base.left}px;top:${rect.top-base.top-1}px;width:${rect.width}px;height:${rect.height+2}px`;bars.append(bar);}}});}
function renderSentences(){
  if(!material)return;
  const list=$('#sentences');list.replaceChildren();
  $('#sentence-count').textContent=`${material.sentences.length} 句字幕`;
  $('#recognition-status').textContent=material.sentences.length?(material.source==='demo'?'演示识别结果':'识别 / 导入结果'):'尚无字幕';
  $('#recognition-status').classList.toggle('warning',material.sentences.some(s=>['pending','missing','partial'].includes(s.alignment)));
  $('#mask-reset').hidden=mask==='none';
  const missing=material.sentences.some(s=>['pending','missing','partial'].includes(s.alignment));
  $('#realign-all').hidden=!missing||!material.sentences.length;
  $('#alignment-note').textContent=missing?'部分文字尚无可靠逐词定位，可重新对齐':'逐词定位为模型估计，可校正文字与边界';
  material.sentences.forEach((s,i)=>{
    const li=element('li','sentence'+(i===current?' active':'')+(isMasked(i)?' masked':''));li.id='sentence-'+i;
    const number=element('button','sentence-number',(i+1).toString().padStart(2,'0'));number.type='button';number.setAttribute('aria-label',`播放第 ${i+1} 句`);number.onclick=protect(()=>playSentence(i));li.append(number);
    const body=element('div','sentence-body');
    if(isMasked(i)){
      const reveal=element('button','sentence-reveal');reveal.type='button';reveal.setAttribute('aria-label',`揭示第 ${i+1} 句字幕`);
      const wrapper=element('div','masked-wrapper'),layout=element('span','mask-layout');layout.setAttribute('aria-hidden','true');
      layout.append(element('span','mask-original',s.text));
      if(showTranslation)layout.append(element('span','sentence-translation',s.translation||'译文尚未生成'));
      const bars=element('span','mask-bars');bars.setAttribute('aria-hidden','true');
      reveal.append(bars);reveal.onclick=e=>{e.stopPropagation();revealed.add(i);renderSentences();};wrapper.append(layout,reveal);body.append(wrapper);
    }else{
      const text=element('button','sentence-play');text.type='button';text.setAttribute('aria-label',`播放第 ${i+1} 句`);
      let offset=0;
      for(let wi=0;wi<s.words.length;wi++){
        const w=s.words[wi],word=w.word.trim(),index=s.text.indexOf(word,offset);if(index<0||!word)continue;
        text.append(document.createTextNode(s.text.slice(offset,index)));
        const span=element('span','word',word);span.dataset.word=wi;text.append(span);offset=index+word.length;
      }
      text.append(document.createTextNode(s.text.slice(offset)));text.onclick=protect(()=>playSentence(i));body.append(text);
      prepareLyrics(text);
      if(showTranslation){const translated=element('div','sentence-translation'+(s.translation?'':' translation-pending'),s.translation||'译文尚未生成');translated.lang='zh-CN';body.append(translated);}
    }
    const info=element('div','sentence-details');info.append(element('span','',`${time(s.start,true)} — ${time(s.end,true)}`));
    if(['pending','missing','partial'].includes(s.alignment))info.append(element('span','sentence-flag',s.alignment==='pending'?'文字已改，待对齐':s.alignment==='partial'?'部分单词未定位':'无逐词定位'));
    body.append(info);li.append(body);
    const edit=element('button','sentence-edit');edit.append(icon('edit'));edit.type='button';edit.setAttribute('aria-label',`校正第 ${i+1} 句`);edit.onclick=()=>openEdit(i);li.append(edit);list.append(li);
  });
  list.classList.toggle('lyrics-enabled',lyricPrefs.enabled);
  requestAnimationFrame(()=>{layoutMaskBars();updatePlayback();});
}

function scrollCurrent(){const el=$('#sentence-'+current);if(!el)return;ignoreScrollUntil=Date.now()+650;el.scrollIntoView({block:'center',behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'instant':'smooth'});}
function browse(){follow=false;$('#follow-toggle').setAttribute('aria-pressed','false');$('#return-current').hidden=false;}
async function playSentence(i){
  if(busy)throw new Error('请等当前处理完成。');
  selecting++;
  try{
  current=i;loop=loop&&i===sentenceIndex(player.current());player.setLoop(loop);$('#loop-toggle').setAttribute('aria-pressed',String(loop));
  renderSentences();if(follow)scrollCurrent();const s=material.sentences[i];await player.playRange(s.start,(loop||$('#sentence-mode').checked)?s.end:material.duration);
  }finally{selecting--;}
}
async function togglePlay(){
  if(!material)return;
  if(player.loading)return;
  if(player.playing){player.pause();saveProgress(true);return;}
  const b=bounds(),pos=player.current(),start=pos>=b.end-.02?b.start:(loop?Math.max(b.start,pos):pos);
  if(loop){await player.prepare(b.start,b.end,false);player.audio.currentTime=(start-b.start)/player.scale;await player.audio.play();}
  else await player.playRange(start,b.end);
}
async function seekTo(pos){
  if(!material)return;
  pos=Math.max(0,Math.min(material.duration,pos));
  const old=bounds();if(loop&&(pos<old.start||pos>=old.end)){loop=false;player.setLoop(false);$('#loop-toggle').setAttribute('aria-pressed','false');}
  current=sentenceIndex(pos);renderSentences();await player.seek(pos,bounds());if(follow)scrollCurrent();saveProgress();
}

function showJob(label,progress=0){$('#job-banner').hidden=false;$('#job-label').textContent=label;$('#job-progress').value=progress;$('#job-detail').textContent=engine==='browser'?'在此设备上运行离线模型，不上传音频。':'使用电脑本地模型，不调用云端接口。';}
async function waitJob(value){
  jobMaterial=value.material;
  while(true){const j=await api('jobs/'+value.job);showJob(j.label,j.progress);if(j.state==='failed')throw new Error(j.error);if(j.state==='done')return {...j.result,kind:'server'};await new Promise(r=>setTimeout(r,700));}
}
function browserTask(type,data,deriveBounds=false){
  if(!isSecureContext)throw new Error('本设备独立识别需通过受信任的 HTTPS 或本机 localhost 打开。当前普通 HTTP 连接只能共享电脑材料。');
  if(!worker){
    worker=new Worker('./asr-worker.js',{type:'module'});
    worker.onmessage=e=>{const task=workerTasks.get(e.data.id);if(!task)return;if(e.data.type==='progress')showJob(e.data.label,e.data.progress);if(e.data.type==='done'){workerTasks.delete(e.data.id);task.resolve(e.data.sentences);}if(e.data.type==='error'){workerTasks.delete(e.data.id);task.reject(new Error(e.data.error));}};
    worker.onerror=e=>{for(const task of workerTasks.values())task.reject(new Error('本设备模型未能载入，请先完成离线资源准备。'+(e.message||'')));workerTasks.clear();worker.terminate();worker=null;};
  }
  const id=crypto.randomUUID(),copy=data.slice();
  return new Promise((resolve,reject)=>{workerTasks.set(id,{resolve,reject});worker.postMessage({id,type,pcm:copy,sentences:material.sentences,deriveBounds},[copy.buffer]);});
}
async function ensureComputerMaterial(){
  if(!server)throw new Error('电脑本地服务未连接，请选择本设备独立识别。');
  if(material.kind==='server')return;
  const original=material,progress=player.current();
  showJob('把材料复制到你的电脑本地服务');
  const copied=await waitJob(await api('materials?name='+encodeURIComponent(original.name),{method:'POST',body:original.audio,headers:{'Content-Type':original.audio.type||'application/octet-stream'}}));
  copied.sentences=validateSentences(original.sentences,copied.duration);copied.progress=Math.min(progress,copied.duration);
  await api(`materials/${copied.id}/save`,{method:'POST',body:JSON.stringify({sentences:copied.sentences,progress:copied.progress})});
  await loadMaterial(copied);
}
async function recognize(){
  cancelTranslation();
  if(!material||busy)return;busy=true;syncAudioSelection();player.pause();showJob('准备离线识别');
  $('#recognition-error').hidden=true;
  try{
    await saveQueue;
    if(engine==='server')await ensureComputerMaterial();
    if(engine==='server'&&material.kind==='server')await loadMaterial(await waitJob(await api(`materials/${material.id}/transcribe`,{method:'POST',body:'{}'})));
    else{material.sentences=validateSentences(await browserTask('transcribe',await pcm()),material.duration);renderSentences();$('#no-subtitles').hidden=true;$('#sentences').hidden=false;$('#loop-toggle').disabled=false;await saveMaterial();await refreshLibrary();}
    toast('字幕已生成。识别文字和单词时间均可校正。');
  }catch(error){$('#recognition-error').textContent='字幕生成未完成：'+(error.message||'请重试。');$('#recognition-error').hidden=false;throw error;}
  finally{busy=false;syncAudioSelection();jobMaterial=null;$('#job-banner').hidden=true;generateTranslation();}
}
async function realign(deriveBounds=false){
  cancelTranslation();
  if(!material||busy)return;busy=true;syncAudioSelection();player.pause();showJob('重新对齐文字');
  try{
    await saveQueue;
    if(engine==='server')await ensureComputerMaterial();
    if(engine==='server'&&material.kind==='server')await loadMaterial(await waitJob(await api(`materials/${material.id}/align`,{method:'POST',body:JSON.stringify({sentences:material.sentences,deriveBounds})})));
    else{material.sentences=validateSentences(await browserTask('align',await pcm(),deriveBounds),material.duration);renderSentences();await saveMaterial();}
    toast('文字已重新对齐，时间边界仍可人工调整。');
  }finally{busy=false;syncAudioSelection();jobMaterial=null;$('#job-banner').hidden=true;generateTranslation();}
}

async function importAudio(file){
  if(!file)return;if(busy)throw new Error('请等当前处理完成。');
  if(!file.name.endsWith('.listen')&&(file.size===0||file.size>100_000_000))throw new Error('单个音频须非空，且不超过 100 MB。');
  let audio=file,backup;
  if(file.name.endsWith('.listen')){backup=await readBackup(file);audio=backup.audio;}
  busy=true;syncAudioSelection();player.pause();showJob('导入并解码音频');
  try{
    await saveMaterial();
    if(engine==='server'&&server){
      const m=await waitJob(await api('materials?name='+encodeURIComponent(backup?.meta.name||file.name),{method:'POST',body:audio,headers:{'Content-Type':audio.type||'application/octet-stream'}}));
      if(backup){m.sentences=validateSentences(backup.meta.sentences,m.duration);m.progress=Math.min(m.duration,backup.meta.progress||0);await api(`materials/${m.id}/save`,{method:'POST',body:JSON.stringify({sentences:m.sentences,progress:m.progress})});}
      await loadMaterial(m);
    }else{
      const decoded=await decodeAudio(audio),m={id:crypto.randomUUID().replaceAll('-',''),kind:'local',name:backup?.meta.name||file.name,audio,pcm:decoded.pcm,duration:decoded.duration,progress:backup?.meta.progress||0,sentences:backup?validateSentences(backup.meta.sentences,decoded.duration):[],source:'import',mime:audio.type};
      await putLocal(m);await loadMaterial(m);
    }
  }finally{busy=false;syncAudioSelection();$('#job-banner').hidden=true;generateTranslation();}
  if(!backup)await recognize();else toast('材料备份已恢复。');
}
async function importSubtitle(file){
  if(!material)throw new Error('请先导入音频，再导入对应的字幕或原文。');
  if(busy)throw new Error('请等当前处理完成。');
  if(file.size>4_000_000)throw new Error('字幕文件过大。');
  const parsed=parseSubtitles(await file.text(),material.duration);player.pause();material.sentences=parsed.sentences;current=0;revealed.clear();
  renderSentences();$('#no-subtitles').hidden=true;$('#sentences').hidden=false;$('#loop-toggle').disabled=false;await saveMaterial();
  await realign(parsed.deriveBounds);
}

function openEdit(index){
  if(busy){toast('请等当前处理完成。');return;}
  cancelTranslation();
  player.pause();editIndex=index;const s=material.sentences[index];$('#edit-text').value=s.text;$('#edit-translation').value=s.translation||'';$('#edit-start').value=s.start;$('#edit-end').value=s.end;
  $('#edit-end').max=material.duration;$('#edit-start').max=material.duration;$('#merge-sentence').disabled=index===material.sentences.length-1;$('#split-time').value='';$('#edit-dialog').showModal();
}
function edited(){
  const original=material.sentences[editIndex],text=$('#edit-text').value.trim(),start=Number($('#edit-start').value),end=Number($('#edit-end').value);
  if(!text||!Number.isFinite(start)||!Number.isFinite(end)||start<0||end<=start||end>material.duration)throw new Error('请填写非空文字，并把起止时间限制在音频范围内。');
  if(editIndex>0&&start<material.sentences[editIndex-1].start||editIndex+1<material.sentences.length&&start>material.sentences[editIndex+1].start)throw new Error('开始时间需要保持句子先后顺序。');
  let translation=$('#edit-translation').value.trim();
  if(text!==original.text&&translation===(original.translation||''))translation='';
  return text===original.text&&start===original.start&&end===original.end?{...original,translation}:{text,start,end,translation,words:[],alignment:'pending'};
}
async function saveEdit(){const updated=edited();cancelTranslation();material.sentences[editIndex]=updated;$('#edit-dialog').close();renderSentences();await saveMaterial();generateTranslation();toast('修改已保存。改变的文字与边界需要重新对齐。');}
async function mergeSentence(){
  const a=edited(),b=material.sentences[editIndex+1];if(!b)return;
  cancelTranslation();
  material.sentences.splice(editIndex,2,{text:a.text+' '+b.text,start:a.start,end:Math.max(a.end,b.end),words:[],alignment:'pending'});
  $('#edit-dialog').close();current=Math.min(current,material.sentences.length-1);renderSentences();await saveMaterial();generateTranslation();toast('两句已合并，请重新对齐文字。');
}
async function splitSentence(){
  const a=edited(),cursor=$('#edit-text').selectionStart,left=a.text.slice(0,cursor).trim(),right=a.text.slice(cursor).trim();
  if(!left||!right)throw new Error('先把文字光标放在两个词之间，再拆句。');
  let split=Number($('#split-time').value);
  if(!$('#split-time').value){
    let charOffset=0,word;
    for(const candidate of a.words){const index=a.text.indexOf(candidate.word.trim(),charOffset);if(index<0)continue;charOffset=index+candidate.word.trim().length;if(index>=cursor&&Number.isFinite(candidate.start)){word=candidate;break;}}
    if(!word)throw new Error('没有可用词边界，请填写“拆句时间（秒）”。不会平均分配时间。');
    split=word.start;
  }
  if(!Number.isFinite(split)||split<=a.start||split>=a.end)throw new Error('拆句时间须在本句起止时间之间。');
  cancelTranslation();material.sentences.splice(editIndex,1,{text:left,start:a.start,end:split,words:[],alignment:'pending'},{text:right,start:split,end:a.end,words:[],alignment:'pending'});
  $('#edit-dialog').close();renderSentences();await saveMaterial();generateTranslation();toast('已拆成两句，请重新对齐文字。');
}

function download(blob,name){const url=URL.createObjectURL(blob),a=element('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);}
function srtStamp(seconds){let ms=Math.round(seconds*1000);const h=Math.floor(ms/3600000);ms%=3600000;const m=Math.floor(ms/60000);ms%=60000;const s=Math.floor(ms/1000);return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')},${String(ms%1000).padStart(3,'0')}`;}
function openExport(entries=null){
  if(busy)throw new Error('请等当前处理完成。');if(!entries?.length&&!material)throw new Error('请先选择音频。');
  exportEntries=entries?.length?[...entries]:null;
  $('#export-title').textContent=exportEntries?`导出选中 ${exportEntries.length} 段`:'导出材料';
  $('#export-help').textContent=exportEntries?'所选文件会打包为一个 ZIP。完整备份含原音频、字幕、译文和练习进度；解压后可将 .listen 文件导入另一设备。':'字幕包含句子时间；备份包含音频、逐词定位和练习进度，可导入另一设备。';
  $('#export-srt span').textContent=exportEntries?'SRT 字幕打包 (ZIP)':'导出 SRT 字幕';
  $('#export-backup span').textContent=exportEntries?'完整材料备份 (ZIP)':'完整材料备份';
  $('#export-progress').hidden=true;$('#export-srt').disabled=$('#export-backup').disabled=false;
  $('#export-dialog').showModal();
}
function srtBlob(m){return new Blob([m.sentences.map((s,i)=>`${i+1}\n${srtStamp(s.start)} --> ${srtStamp(s.end)}\n${s.text}${showTranslation&&s.translation?'\n'+s.translation:''}\n`).join('\n')],{type:'text/plain;charset=utf-8'});}
async function exportMaterials(format){
  if(busy)throw new Error('请等当前处理完成。');
  const batch=exportEntries!==null,entries=batch?[...exportEntries]:material?[{id:material.id,kind:material.kind,name:material.name}]:[];
  if(!entries.length)throw new Error('请先选择音频。');
  busy=true;syncAudioSelection();$('#export-srt').disabled=$('#export-backup').disabled=true;
  $('#export-progress').hidden=false;$('#export-progress').textContent='正在准备导出…';
  let snapshot=null;
  try{
    await saveQueue;
    if(material&&entries.some(m=>audioKey(m)===audioKey(material))){await saveMaterial();snapshot={...material,sentences:structuredClone(material.sentences),progress:player.current()};delete snapshot.pcm;}
    async function* files(){
      for(let i=0;i<entries.length;i++){
        const entry=entries[i];$('#export-progress').textContent=`正在导出 ${i+1} / ${entries.length}：${entry.name}`;
        const m=snapshot&&audioKey(entry)===audioKey(snapshot)?snapshot:entry.kind==='server'?{...(await api('materials/'+entry.id)),kind:'server'}:await getLocal(entry.id);
        if(!m)throw new Error('这段音频已删除：'+entry.name);
        if(format==='srt')yield {name:m.name+'.srt',blob:srtBlob(m)};
        else{
          let audio=m.audio;
          if(m.kind==='server'){
            const response=await fetch(mediaURL(`materials/${m.id}/original`));
            if(!response.ok)throw new Error('原音频无法读取：'+m.name);audio=await response.blob();
          }
          if(!(audio instanceof Blob)||!audio.size)throw new Error('原音频缺失：'+m.name);
          yield {name:m.name+'.listen',blob:backupBlob(m,audio)};
        }
      }
    }
    if(batch){const blob=await zipFiles(files());download(blob,`听练_${format==='srt'?'字幕':'材料备份'}_${entries.length}段.zip`);}
    else for await(const file of files())download(file.blob,safeFileName(file.name));
    $('#export-dialog').close();toast(batch?`已导出所选 ${entries.length} 段${format==='srt'?'字幕':'完整材料备份'}。`:'已导出材料。');
  }finally{busy=false;$('#export-srt').disabled=$('#export-backup').disabled=false;$('#export-progress').hidden=true;syncAudioSelection();generateTranslation();}
}

async function offlineStatus(){
  const state=await getOfflineState();
  $('#offline-prepare').disabled=!state.available;
  $('#offline-state').textContent=state.ready?'应用和模型已保存，可以在此设备上断网使用。':state.available?'首次识别或翻译需要模型。可点击下方按钮下载并保存，也可先练习已有字幕。':'请通过 HTTPS 网址打开此网页。';
}
async function prepareOffline(){
  $('#offline-prepare').disabled=true;
  try{await prepareResources();await offlineStatus();toast('资源准备完成，请在此设备断网后验证。');}
  finally{$('#offline-prepare').disabled=false;}
}
function updateEngine(){
  $('#recognition-engine option[value="server"]').disabled=!server;
  $('#recognition-engine').value=engine;
  $('#engine-help').textContent=engine==='browser'?'在此设备浏览器运行英语模型，音频不上传到服务器。首次使用需要下载模型，保存后可以离线使用。':'使用电脑本地模型。本设备材料会复制到你的电脑；手机选择此方式时，音频传给电脑进行识别。';
  $('#recognize-route').textContent=engine==='browser'?'在此设备运行模型；首次使用需下载资源':'使用电脑本地模型';
}

for(let i=1;i<=25;i++)$('#rate-select').add(new Option((i/10).toFixed(1)+' ×',i/10));
player.rate=Number(prefs.rate)||1;$('#rate-select').value=String(player.rate);
setFontSize(prefs.font||24,false);setSubtitleDensity(prefs.density??80,false);$('#translation-enabled').checked=showTranslation;translationStatus(showTranslation?'译文已开启':'译文已关闭');
$('#theme').value=prefs.theme||'light';applyTheme();updateEngine();
syncLyricSettings();
$('#audio-library-open').onclick=protect(async()=>{$('#audio-search').value='';await refreshLibrary();$('#audio-library-dialog').showModal();});
$('#audio-library-expand').onclick=()=>$('#audio-library-open').click();
$('#audio-search').oninput=()=>{selectedAudio.clear();renderAudioList();};$('#audio-sort').onchange=renderAudioList;
$('#library-batch-toggle').onclick=$('#audio-batch-toggle').onclick=()=>{if(!busy)setAudioBatchMode(!audioBatchMode);};
$('#library-select-all').onchange=e=>selectAudio(libraryEntries,e.target.checked);
$('#audio-select-all').onchange=e=>selectAudio(filteredAudioEntries(),e.target.checked);
$('#library-delete-selected').onclick=$('#audio-delete-selected').onclick=protect(()=>deleteAudio(libraryEntries.filter(m=>selectedAudio.has(audioKey(m)))));
$('#library-export-selected').onclick=$('#audio-export-selected').onclick=protect(()=>openExport(libraryEntries.filter(m=>selectedAudio.has(audioKey(m)))));
$('#library-undo-delete').onclick=$('#audio-undo-delete').onclick=protect(undoDeleteAudio);
$('#lyric-settings-open').onclick=()=>$('#lyric-dialog').showModal();
$('#lyrics-enable').onchange=e=>{lyricPrefs.enabled=e.target.checked;syncLyricSettings();storePrefs();};
$('#lyric-word-highlight').onchange=e=>{lyricPrefs.wordHighlight=e.target.checked;syncLyricSettings();storePrefs();};
$('#lyric-color').oninput=e=>setLyricColor(e.target.value);
$('#lyric-hex').oninput=e=>{const value=e.target.value.trim();if(/^#?[a-f\d]{6}$/i.test(value))setLyricColor('#'+value.replace('#',''));else $('#lyric-color-error').textContent='请输入 6 位 HEX 颜色，例如 #CBD2EF。';};
['r','g','b'].forEach(n=>$('#lyric-'+n).oninput=()=>{const strings=['r','g','b'].map(k=>$('#lyric-'+k).value),values=strings.map(Number);if(strings.some(v=>v==='')||values.some(v=>!Number.isInteger(v)||v<0||v>255)){$('#lyric-color-error').textContent='RGB 每项需要为 0–255 的整数。';return;}setLyricColor('#'+values.map(v=>v.toString(16).padStart(2,'0')).join(''));});
all('[data-lyric-color]').forEach(b=>b.onclick=()=>setLyricColor(b.dataset.lyricColor));
$('.brand').onclick=e=>e.preventDefault();
all('.import-trigger').forEach(b=>b.onclick=()=>$('#audio-input').click());
$('#audio-input').onchange=protect(async e=>{const file=e.target.files[0];e.target.value='';await importAudio(file);});
$('#subtitle-import').onclick=()=>{if(!material){toast('请先导入音频。');return;}$('#subtitle-input').click();};
$('#subtitle-input').onchange=protect(async e=>{const file=e.target.files[0];e.target.value='';if(file)await importSubtitle(file);});
$('#settings-open').onclick=protect(async()=>{await offlineStatus();$('#settings-dialog').showModal();});
$('#export-open').onclick=protect(()=>openExport(audioBatchMode&&selectedAudio.size?libraryEntries.filter(m=>selectedAudio.has(audioKey(m))):null));
all('.dialog-close').forEach(b=>b.onclick=()=>b.closest('dialog').close());
$('#edit-dialog').addEventListener('close',()=>setTimeout(generateTranslation,0));
all('dialog').forEach(d=>d.addEventListener('click',e=>{if(e.target===d){const r=d.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)d.close();}}));
$('#library-open').onclick=()=>$('#library-panel').classList.add('open');$('#library-close').onclick=()=>$('#library-panel').classList.remove('open');
$('#font-size').oninput=e=>setFontSize(e.target.value);
$('#subtitle-density').oninput=e=>setSubtitleDensity(e.target.value);
$('#density-number').oninput=e=>{if(e.target.value!==''&&e.target.validity.valid)setSubtitleDensity(e.target.value);};
$('#density-number').onchange=e=>setSubtitleDensity(e.target.value===''?$('#subtitle-density').value:e.target.value);
$('#font-decrease').onclick=()=>setFontSize(Number($('#font-size').value)-2);$('#font-increase').onclick=()=>setFontSize(Number($('#font-size').value)+2);
$('#translation-enabled').onchange=e=>{showTranslation=e.target.checked;cancelTranslation();storePrefs();renderSentences();generateTranslation();};
$('#translation-generate').onclick=()=>{if(!showTranslation){showTranslation=true;$('#translation-enabled').checked=true;storePrefs();renderSentences();}generateTranslation();};
$('#theme').onchange=()=>{applyTheme();storePrefs();};matchMedia('(prefers-color-scheme:dark)').addEventListener('change',applyTheme);
$('#recognition-engine').onchange=e=>{engine=e.target.value;updateEngine();storePrefs();};
$('#mask-mode').onchange=e=>{mask=e.target.value;revealed.clear();renderSentences();};$('#mask-reset').onclick=()=>{revealed.clear();renderSentences();};
$('#follow-toggle').onclick=()=>{follow=!follow;$('#follow-toggle').setAttribute('aria-pressed',String(follow));$('#return-current').hidden=follow;if(follow)scrollCurrent();};
$('#return-current').onclick=()=>{follow=true;$('#follow-toggle').setAttribute('aria-pressed','true');$('#return-current').hidden=true;scrollCurrent();};
$('#transcript-scroll').addEventListener('wheel',browse,{passive:true});$('#transcript-scroll').addEventListener('touchmove',browse,{passive:true});$('#transcript-scroll').addEventListener('keydown',e=>{if(['ArrowDown','ArrowUp','PageDown','PageUp','Home','End'].includes(e.key))browse();});
$('#play-toggle').onclick=protect(togglePlay);$('#prev-sentence').onclick=protect(()=>playSentence(Math.max(0,current-1)));$('#next-sentence').onclick=protect(()=>playSentence(Math.min(material.sentences.length-1,current+1)));
all('[data-jump]').forEach(b=>b.onclick=protect(()=>seekTo(player.current()+Number(b.dataset.jump))));$('#seek').onchange=protect(e=>seekTo(Number(e.target.value)));
$('#loop-toggle').onclick=protect(async()=>{
  if(!material.sentences.length)return;loop=!loop;player.setLoop(loop);$('#loop-toggle').setAttribute('aria-pressed',String(loop));
  if(loop&&player.playing){const s=material.sentences[current],pos=player.current();await player.prepare(s.start,s.end,false);player.audio.currentTime=Math.max(0,(pos-s.start)/player.scale);await player.audio.play();}
});
$('#sentence-mode').onchange=protect(async()=>{if(player.playing){const pos=player.current();await player.prepare(pos,bounds().end,true);}});
async function setRate(rate){$('#rate-select').value=String(rate);all('[data-rate]').forEach(b=>b.classList.toggle('active',Number(b.dataset.rate)===rate));await player.setRate(rate,bounds());storePrefs();}
$('#rate-select').onchange=protect(e=>setRate(Number(e.target.value)));all('[data-rate]').forEach(b=>b.onclick=protect(()=>setRate(Number(b.dataset.rate))));
$('#recognize-start').onclick=protect(recognize);$('#realign-all').onclick=protect(()=>realign(false));
$('#edit-form').onsubmit=protect(async e=>{e.preventDefault();await saveEdit();});$('#merge-sentence').onclick=protect(mergeSentence);$('#split-sentence').onclick=protect(splitSentence);
$('#export-srt').onclick=protect(()=>exportMaterials('srt'));$('#export-backup').onclick=protect(()=>exportMaterials('backup'));
$('#offline-prepare').onclick=protect(prepareOffline);
document.addEventListener('dragover',e=>{if(e.dataTransfer.types.includes('Files')){e.preventDefault();document.body.classList.add('dragging');}});document.addEventListener('dragleave',e=>{if(!e.relatedTarget)document.body.classList.remove('dragging');});document.addEventListener('drop',protect(async e=>{e.preventDefault();document.body.classList.remove('dragging');await importAudio(e.dataTransfer.files[0]);}));
window.addEventListener('resize',()=>{if(material?.pcm)drawWaveform(material.pcm);layoutMaskBars();all('.sentence-play').forEach(b=>b._lyricSegments=null);updatePlayback();});document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')saveProgress(true);});window.addEventListener('pagehide',()=>{if(material?.kind==='server'){fetch('./api/materials/'+material.id+'./save',{method:'POST',keepalive:true,headers:{'Content-Type':'application/json',...(token?{'X-Listen-Token':token}:{})},body:JSON.stringify({progress:player.current()})}).catch(()=>{});}else saveProgress(true);});
if('mediaSession'in navigator){for(const [action,handler]of Object.entries({play:()=>protect(togglePlay)(),pause:()=>player.pause(),previoustrack:()=>protect(()=>playSentence(Math.max(0,current-1)))(),nexttrack:()=>protect(()=>playSentence(Math.min(material.sentences.length-1,current+1)))(),seekbackward:d=>protect(()=>seekTo(player.current()-(d.seekOffset||10)))(),seekforward:d=>protect(()=>seekTo(player.current()+(d.seekOffset||10)))(),seekto:d=>protect(()=>seekTo(d.seekTime))()})){try{navigator.mediaSession.setActionHandler(action,handler);}catch{}}}
async function init(){
  server=null;engine='browser';
  updateEngine();
  $('#connection-label').textContent='好友分享版';$('#share-state').textContent='点击页面顶部“使用 / 分享”复制网址。好友可在不同网络打开，各自的材料保存在自己的浏览器中。';
  try{await ensureRegistration();}catch(error){toast(error.message);}
  await offlineStatus();await refreshLibrary();
  try{const last=JSON.parse(localStorage.getItem('listen-share-last')||'null');if(last){const m=last.kind==='server'&&server?{...(await api('materials/'+last.id)),kind:'server'}:await getLocal(last.id);if(m)await loadMaterial(m);}}catch{}
  updatePlayback();
}
protect(init)();

document.addEventListener('listen-share-demo',protect(async()=>{
  if(busy)throw new Error('请等当前处理完成。');await saveMaterial();let demo=await getLocal('demo');
  if(!demo){const response=await fetch('./demo/material.json');if(!response.ok)throw new Error('演示资源无法加载，请检查网络。');demo=await response.json();demo.audio=await(await fetch('./demo/audio.wav')).blob();demo.kind='local';await putLocal(demo);}
  await loadMaterial(demo);
}));
