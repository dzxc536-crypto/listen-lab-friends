export class Player{
  constructor(audio,getClip,update){
    this.audio=audio;this.getClip=getClip;this.update=update;
    this.rate=1;this.duration=0;this.start=0;this.end=0;this.scale=1;this.position=0;this.sequence=0;this.loop=false;this.playing=false;this.ready=false;this.loading=false;
    audio.preservesPitch=true;
    audio.addEventListener('timeupdate',()=>this.emit());
    audio.addEventListener('play',()=>{this.playing=true;this.animate();this.emit();});
    audio.addEventListener('pause',()=>{this.playing=false;this.emit();});
    audio.addEventListener('ended',()=>{this.playing=false;this.position=this.end;this.emit();this.onEnded?.();});
    audio.addEventListener('error',()=>{this.playing=false;this.loading=false;this.emit();});
  }
  current(){return this.ready?Math.min(this.duration,this.start+this.audio.currentTime*this.scale):this.position;}
  emit(){this.update?.(this);}
  animate(){cancelAnimationFrame(this.animation);const tick=()=>{this.emit();if(this.playing)this.animation=requestAnimationFrame(tick);};this.animation=requestAnimationFrame(tick);}
  reset(duration,position=0){this.sequence++;this.audio.pause();this.audio.removeAttribute('src');this.audio.load();this.ready=false;this.loading=false;this.duration=duration;this.position=Math.min(duration,Math.max(0,position));this.loop=false;this.playing=false;this.emit();}
  pause(){this.position=this.current();this.audio.pause();this.playing=false;this.emit();}
  async prepare(start,end,play=false){
    if(end<=start)return;
    const sequence=++this.sequence;
    this.audio.pause();this.position=start;this.ready=false;this.loading=true;this.emit();
    try{
      const scale=this.rate<.5?this.rate:1;
      const url=await this.getClip(start,end,scale);
      if(sequence!==this.sequence){if(url.startsWith('blob:'))URL.revokeObjectURL(url);return;}
      if(this.blobURL)URL.revokeObjectURL(this.blobURL);this.blobURL=url.startsWith('blob:')?url:null;
      this.start=start;this.end=end;this.scale=scale;this.audio.src=url;
      this.audio.defaultPlaybackRate=scale===1?this.rate:1;this.audio.playbackRate=this.audio.defaultPlaybackRate;this.audio.preservesPitch=true;this.audio.loop=this.loop;
      await new Promise((resolve,reject)=>{
        const clean=()=>{this.audio.removeEventListener('canplay',ok);this.audio.removeEventListener('error',bad);};
        const ok=()=>{clean();resolve();};const bad=()=>{clean();reject(new Error('此设备无法播放解码后的音频。'));};
        this.audio.addEventListener('canplay',ok,{once:true});this.audio.addEventListener('error',bad,{once:true});this.audio.load();
      });
      if(sequence!==this.sequence)return;
      this.audio.playbackRate=scale===1?this.rate:1;this.audio.preservesPitch=true;
      this.ready=true;this.loading=false;this.emit();
      if(play)await this.audio.play();
    }catch(e){if(sequence===this.sequence){this.loading=false;this.emit();}throw e;}
  }
  async playRange(start,end){
    if(this.ready&&Math.abs(this.start-start)<.005&&Math.abs(this.end-end)<.005){if(this.current()>=end-.01)this.audio.currentTime=0;await this.audio.play();}
    else await this.prepare(start,end,true);
  }
  async seek(position,bounds){
    const playing=this.playing;position=Math.max(0,Math.min(this.duration,position));
    if(position>=this.duration){this.pause();this.ready=false;this.position=this.duration;this.emit();return;}
    if(this.ready&&position>=this.start&&position<this.end){this.audio.currentTime=(position-this.start)/this.scale;this.emit();return;}
    this.sequence++;this.audio.pause();this.ready=false;this.position=position;this.emit();
    if(playing)await this.prepare(position,bounds.end,true);
  }
  setLoop(on){this.loop=on;this.audio.loop=on;this.emit();}
  async setRate(rate,bounds){
    const position=this.current(),playing=this.playing;this.rate=rate;
    if(this.ready&&this.scale===1&&rate>=.5){this.audio.defaultPlaybackRate=rate;this.audio.playbackRate=rate;this.audio.preservesPitch=true;this.emit();return;}
    if(this.ready&&playing){const start=this.loop?bounds.start:position;await this.prepare(start,bounds.end,false);this.audio.currentTime=(position-start)/this.scale;await this.audio.play();}
    else{this.sequence++;this.ready=false;this.loading=false;this.position=position;this.emit();}
  }
}
