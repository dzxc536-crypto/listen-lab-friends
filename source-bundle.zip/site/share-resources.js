const manifestURL=new URL('./offline-assets.json',import.meta.url);
const readyURL=new URL('./offline-ready',import.meta.url).href;
let registrationPromise,manifestPromise,preparing;
export const getManifest=()=>manifestPromise??=fetch(manifestURL).then(r=>{if(!r.ok)throw new Error('无法读取资源清单，请检查网络后重试。');return r.json();});
export async function ensureRegistration(){
  if(!isSecureContext||!('serviceWorker' in navigator))throw new Error('请通过 HTTPS 网址打开；本地预览请使用 localhost，不能直接双击网页文件。');
  if(!registrationPromise){
    registrationPromise=(async()=>{
      await navigator.serviceWorker.register(new URL('./sw.js',import.meta.url),{scope:new URL('./',import.meta.url).pathname});
      const ready=await Promise.race([navigator.serviceWorker.ready,new Promise((_,reject)=>setTimeout(()=>reject(new Error('离线应用准备超时，请刷新页面后重试。')),20000))]);
      // Activate isolation only during idle startup, once per release. Unsupported browsers continue normally.
      const release=(await getManifest()).release;
      if(!navigator.serviceWorker.controller)await new Promise(resolve=>{
        const done=()=>{clearTimeout(timer);navigator.serviceWorker.removeEventListener('controllerchange',done);resolve();};
        const timer=setTimeout(done,2000);navigator.serviceWorker.addEventListener('controllerchange',done);
      });
      if(self.crossOriginIsolated===false&&navigator.serviceWorker.controller&&sessionStorage.getItem('listen-speed-reload')!==release&&document.querySelector('#job-banner')?.hidden!==false){
        sessionStorage.setItem('listen-speed-reload',release);
        location.reload();
      }
      return ready;
    })().catch(e=>{registrationPromise=null;throw e;});
  }
  return registrationPromise;
}
export async function getOfflineState(){
  if(!isSecureContext||!('serviceWorker' in navigator))return {ready:false,available:false};
  const manifest=await getManifest(),response=await caches.match(readyURL);
  const value=response?await response.json():null;
  return {available:true,ready:value?.modelSet===manifest.modelSet,manifest};
}
export function prepareResources(){
  if(preparing)return preparing;
  preparing=(async()=>{
    const registration=await ensureRegistration();
    if(navigator.storage?.persist)try{await navigator.storage.persist();}catch{}
    return new Promise((resolve,reject)=>{
      const channel=new MessageChannel();let timeout;
      const refresh=()=>{clearTimeout(timeout);timeout=setTimeout(()=>{channel.port1.close();reject(new Error('下载长时间没有进展，请检查网络后重试。已保存的文件会保留。'));},120000);};
      channel.port1.onmessage=({data})=>{
        refresh();document.dispatchEvent(new CustomEvent('listen-resources-progress',{detail:data}));
        if(data.state==='done'||data.state==='error'){
          clearTimeout(timeout);channel.port1.close();
          if(data.state==='done')resolve(data);else reject(new Error(data.error));
        }
      };
      refresh();registration.active.postMessage({type:'PREPARE'},[channel.port2]);
    });
  })().finally(()=>{preparing=null;});
  return preparing;
}
