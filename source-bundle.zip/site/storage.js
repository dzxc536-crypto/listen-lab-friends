const request = req => new Promise((resolve,reject)=>{req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});
let database;
async function db(){
  if(database)return database;
  database=await new Promise((resolve,reject)=>{const r=indexedDB.open('listen-lab-friends',1);r.onupgradeneeded=()=>r.result.createObjectStore('materials',{keyPath:'id'});r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});
  return database;
}
export async function listLocal(){const d=await db();return (await request(d.transaction('materials').objectStore('materials').getAll())).filter(m=>!m.deletedAt);}
export async function getLocal(id){const d=await db();const m=await request(d.transaction('materials').objectStore('materials').get(id));return m?.deletedAt?undefined:m;}
export async function putLocal(material){
  const d=await db();const copy={...material};delete copy.pcm;delete copy.url;copy.updated=Date.now()/1000;
  await new Promise((resolve,reject)=>{const tx=d.transaction('materials','readwrite'),store=tx.objectStore('materials'),read=store.get(copy.id);read.onsuccess=()=>{if(read.result?.deletedAt){tx.abort();return;}store.put(copy);};tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||new Error('材料已删除，未重新写入。'));});
}
async function markLocal(ids,restore){
  const d=await db(),changed=[];
  await new Promise((resolve,reject)=>{
    const tx=d.transaction('materials','readwrite'),store=tx.objectStore('materials');
    for(const id of new Set(ids)){
      const read=store.get(id);read.onsuccess=()=>{const m=read.result;if(!m)return;if(restore)delete m.deletedAt;else m.deletedAt=Date.now();store.put(m);changed.push(id);};
    }
    tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||new Error('材料列表更新失败。'));
  });
  return changed;
}
export const deleteLocal=ids=>markLocal(ids,false);
export const restoreLocal=ids=>markLocal(ids,true);
export async function decodeAudio(blob){
  const context=new AudioContext();
  try{
    const decoded=await context.decodeAudioData(await blob.arrayBuffer());
    const frames=Math.ceil(decoded.duration*16000);
    const offline=new OfflineAudioContext(1,frames,16000);
    const src=offline.createBufferSource();src.buffer=decoded;src.connect(offline.destination);src.start();
    const mono=await offline.startRendering();
    return {pcm:mono.getChannelData(0),duration:mono.duration};
  }catch(error){throw new Error('此设备无法解码音频，或内存不足。请先将文件转换为 WAV 或 MP3，再导入；也可尝试较短的音频。');}
  finally{await context.close();}
}
export function wavClip(pcm,start,end,rate=1){
  const a=Math.floor(Math.max(0,start)*16000),b=Math.min(pcm.length,Math.ceil(end*16000));
  const frames=Math.ceil((b-a)/rate),bytes=frames*2;
  if(bytes>0xffffffff-36)throw new Error('此播放区间解码后过大，请改用逐句播放。');
  const header=new ArrayBuffer(44),v=new DataView(header);
  const text=(offset,s)=>{for(let i=0;i<s.length;i++)v.setUint8(offset+i,s.charCodeAt(i));};
  text(0,'RIFF');v.setUint32(4,36+bytes,true);text(8,'WAVE');text(12,'fmt ');v.setUint32(16,16,true);v.setUint16(20,1,true);v.setUint16(22,1,true);v.setUint32(24,16000,true);v.setUint32(28,32000,true);v.setUint16(32,2,true);v.setUint16(34,16,true);text(36,'data');v.setUint32(40,bytes,true);
  const parts=[header],block=1<<20;
  for(let offset=0;offset<frames;offset+=block){
    const out=new Int16Array(Math.min(block,frames-offset));
    for(let i=0;i<out.length;i++){
      const index=a+(offset+i)*rate,lo=Math.floor(index),frac=index-lo;
      const x=(pcm[Math.min(b-1,lo)]||0)*(1-frac)+(pcm[Math.min(b-1,lo+1)]||0)*frac;
      out[i]=Math.round(Math.max(-1,Math.min(1,x))*32767);
    }
    parts.push(out.buffer);
  }
  return new Blob(parts,{type:'audio/wav'});
}
export function validateSentences(sentences,duration){
  if(!Array.isArray(sentences))throw new Error('字幕文件结构无效。');
  return sentences.map(s=>{
    const start=Number(s.start),end=Number(s.end),text=String(s.text||'').trim();
    if(!text||!Number.isFinite(start)||!Number.isFinite(end)||start<0||end<=start||end>duration+.05)throw new Error('字幕有空文字或无效时间，请检查起止时间。');
    return {text,start,end:Math.min(duration,end),translation:String(s.translation||'').trim(),words:Array.isArray(s.words)?s.words.map(w=>({word:String(w.word||''),...(Number.isFinite(w.start)&&Number.isFinite(w.end)&&w.start>=0&&w.end>w.start&&w.end<=duration+.05?{start:w.start,end:w.end}:{})})):[],alignment:s.alignment||'missing'};
  }).sort((a,b)=>a.start-b.start);
}
function stamp(s){const pieces=s.trim().replace(',','.').split(':').map(Number);return pieces.reduce((a,b)=>a*60+b,0);}
export function parseSubtitles(text,duration){
  const cleaned=text.replace(/^\uFEFF/,'').replace(/\r/g,'');
  if(cleaned.trim().startsWith('{')||cleaned.trim().startsWith('[')){
    const json=JSON.parse(cleaned);return {sentences:validateSentences(Array.isArray(json)?json:json.sentences,duration),deriveBounds:false};
  }
  if(cleaned.includes('-->')){
    const sentences=[];
    for(const block of cleaned.split(/\n\s*\n/)){
      const lines=block.split('\n'),i=lines.findIndex(l=>l.includes('-->'));if(i<0)continue;
      const match=lines[i].match(/(\d{1,2}:\d{2}(?::\d{2})?[,.]\d+)\s*-->\s*(\d{1,2}:\d{2}(?::\d{2})?[,.]\d+)/);
      if(!match)throw new Error('无法读取字幕中的时间格式。');
      const content=lines.slice(i+1).map(l=>l.replace(/<[^>]*>/g,'').trim()).filter(Boolean);
      const original=content.filter(l=>!/[\u3400-\u9fff]/u.test(l)).join(' ');
      const translation=content.filter(l=>/[\u3400-\u9fff]/u.test(l)).join(' ');
      if(content.length)sentences.push({start:stamp(match[1]),end:stamp(match[2]),text:original||content.join(' '),translation:original?translation:'',words:[],alignment:'missing'});
    }
    if(!sentences.length)throw new Error('没有找到带时间的字幕。');
    return {sentences:validateSentences(sentences,duration),deriveBounds:false};
  }
  if(!cleaned.trim())throw new Error('原文为空。');
  return {sentences:[{text:cleaned.trim(),start:0,end:duration,words:[],alignment:'pending'}],deriveBounds:true};
}
export function backupBlob(material,audio){
  const meta={...material};delete meta.audio;delete meta.pcm;delete meta.url;delete meta.kind;
  const json=new TextEncoder().encode(JSON.stringify(meta)),header=new Uint8Array(12);
  header.set(new TextEncoder().encode('LISTEN01'));new DataView(header.buffer).setUint32(8,json.length,true);
  return new Blob([header,json,audio],{type:'application/octet-stream'});
}
export async function readBackup(file){
  const header=await file.slice(0,12).arrayBuffer();
  if(new TextDecoder().decode(header.slice(0,8))!=='LISTEN01')throw new Error('不是有效的听练材料备份。');
  const length=new DataView(header).getUint32(8,true);
  if(length>4_000_000||12+length>=file.size)throw new Error('备份头部或音频数据不完整。');
  const meta=JSON.parse(await file.slice(12,12+length).text()),audio=file.slice(12+length,file.size,meta.mime||'audio/wav');
  if(audio.size>100_000_000)throw new Error('备份中的原音频超过 100 MB。');
  return {meta,audio};
}
