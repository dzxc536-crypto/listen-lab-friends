const RELEASE='20261004-110203',MODEL_SET='de4b78c60ca7de72';
const base=new URL('./',self.location.href),scopeKey=encodeURIComponent(base.pathname);
const SHELL=`listen-share-shell-${scopeKey}-${RELEASE}`,MODELS=`listen-share-models-${scopeKey}-${MODEL_SET}`;
const absolute=path=>new URL(path,base).href;
const shell=["./", "./THIRD_PARTY.md", "./app.js", "./asr-segments.js", "./asr-worker.js", "./demo/audio.wav", "./demo/material.json", "./icon.svg", "./index.html", "./lyrics.js", "./manifest.webmanifest", "./pitch-clip.js", "./player.js", "./share-resources.js", "./share-setup.js", "./share.css", "./storage.js", "./styles.css", "./translation-worker.js", "./zip.js", "./offline-assets.json", "./vendor/soundtouch/constants.js", "./vendor/soundtouch/LICENSE.txt", "./vendor/soundtouch/processOffline.js", "./vendor/soundtouch/soundtouch-processor.js", "./vendor/soundtouch/SoundTouchNode.js"];
const inFlight=new Map();
let manifestPromise;
async function manifest(){
  if(!manifestPromise)manifestPromise=(async()=>{
    try{const r=await fetch(absolute('./offline-assets.json'),{cache:'no-cache'});if(!r.ok)throw new Error('清单不可用');return await r.json();}
    catch(error){const r=await (await caches.open(SHELL)).match(absolute('./offline-assets.json'));if(!r)throw error;return r.json();}
  })().catch(error=>{manifestPromise=null;throw error;});
  return manifestPromise;
}
const modelAsset=url=>url.pathname.startsWith(base.pathname+'models/')||url.pathname.startsWith(base.pathname+'vendor/');
function isolatedResponse(response){
  if(response.status===0)return response;
  const headers=new Headers(response.headers);
  headers.set('Cross-Origin-Opener-Policy','same-origin');
  headers.set('Cross-Origin-Embedder-Policy','require-corp');
  headers.set('Cross-Origin-Resource-Policy','same-origin');
  return new Response(response.body,{status:response.status,statusText:response.statusText,headers});
}
async function saveAsset(url,cacheName,expected=0,onBytes=()=>{}){
  const cache=await caches.open(cacheName),cached=await cache.match(url);
  if(cached){onBytes(expected);return cached;}
  if(inFlight.has(url)){await inFlight.get(url);onBytes(expected);return cache.match(url);}
  const promise=(async()=>{
    const response=await fetch(url,{cache:'no-cache'});
    if(!response.ok)throw new Error(`文件下载失败（${response.status}）：${new URL(url).pathname.split('/').at(-1)}`);
    let received=0;
    const headers=new Headers(response.headers);headers.delete('content-encoding');headers.delete('content-length');
    if(expected)headers.set('content-length',String(expected));
    const stream=response.body.pipeThrough(new TransformStream({transform(chunk,controller){received+=chunk.byteLength;onBytes(chunk.byteLength);controller.enqueue(chunk);}}));
    await cache.put(url,new Response(stream,{status:200,headers}));
    if(expected&&received!==expected){await cache.delete(url);throw new Error('下载文件不完整，请重试。');}
  })().finally(()=>inFlight.delete(url));
  inFlight.set(url,promise);await promise;return cache.match(url);
}
self.addEventListener('install',event=>event.waitUntil((async()=>{
  const cache=await caches.open(SHELL);
  await cache.addAll(shell.map(absolute));await self.skipWaiting();
})()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{
  for(const key of await caches.keys())if(key.startsWith(`listen-share-shell-${scopeKey}-`)&&key!==SHELL)await caches.delete(key);
  await self.clients.claim();
})()));
self.addEventListener('fetch',event=>{
  const url=new URL(event.request.url);
  if(url.origin!==base.origin||!url.pathname.startsWith(base.pathname)||event.request.method!=='GET')return;
  if(url.pathname.startsWith(base.pathname+'api/'))return;
  if(modelAsset(url)){
    event.respondWith((async()=>{const m=await manifest(),path='./'+url.pathname.slice(base.pathname.length);return isolatedResponse(await saveAsset(url.href,MODELS,m.assetBytes[path]||0));})());return;
  }
  event.respondWith((async()=>{
    const cache=await caches.open(SHELL),cached=await cache.match(event.request);
    if(cached)return isolatedResponse(cached);
    try{return isolatedResponse(await fetch(event.request));}
    catch{return event.request.mode==='navigate'?isolatedResponse((await cache.match(base.href))||Response.error()):Response.error();}
  })());
});
let preparePromise;
self.addEventListener('message',event=>{
  if(event.data.type!=='PREPARE')return;
  const port=event.ports[0];if(!port)return;
  event.waitUntil((async()=>{
    if(preparePromise){await preparePromise;port.postMessage({state:'done'});return;}
    preparePromise=(async()=>{
      const m=await manifest();let completed=0,completedBytes=0,last=0;
      const progress=force=>{const now=Date.now();if(force||now-last>150){last=now;port.postMessage({state:'progress',completed,total:m.assets.length,completedBytes,totalBytes:m.totalBytes});}};
      for(const path of m.assets){
        const url=absolute(path),name=modelAsset(new URL(url))?MODELS:SHELL;
        await saveAsset(url,name,m.assetBytes[path]||0,bytes=>{completedBytes+=bytes;progress(false);});
        completed++;progress(true);
      }
      await (await caches.open(MODELS)).put(absolute('./offline-ready'),new Response(JSON.stringify({date:Date.now(),modelSet:MODEL_SET})));
      for(const key of await caches.keys())if(key.startsWith(`listen-share-models-${scopeKey}-`)&&key!==MODELS)await caches.delete(key);
      port.postMessage({state:'done',completedBytes,totalBytes:m.totalBytes});
    })();
    try{await preparePromise;}finally{preparePromise=null;}
  })().catch(error=>port.postMessage({state:'error',error:error.message||'下载失败，请检查网络后重试。'})));
});
