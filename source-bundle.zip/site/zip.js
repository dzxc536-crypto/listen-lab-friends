// Uncompressed ZIP keeps original audio intact and works without external libraries.
const encoder=new TextEncoder(),MAX32=0xffffffff;
const crcTable=Uint32Array.from({length:256},(_,n)=>{
  for(let bit=0;bit<8;bit++)n=(n>>>1)^((n&1)?0xedb88320:0);
  return n>>>0;
});
async function crc32(blob){
  const reader=blob.stream().getReader();let crc=MAX32;
  try{
    for(;;){const {value,done}=await reader.read();if(done)break;for(const byte of value)crc=(crc>>>8)^crcTable[(crc^byte)&255];}
  }finally{reader.releaseLock();}
  return (crc^MAX32)>>>0;
}
export function safeFileName(value){
  let name=Array.from(String(value||'材料').replace(/[\u0000-\u001f\u007f<>:"/\\|?*]/g,'_')).slice(0,200).join('').replace(/[. ]+$/g,'').trim();
  if(/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(name))name='_'+name;
  return name||'材料';
}
export async function zipFiles(files){
  const parts=[],central=[],used=new Set(),now=new Date();let offset=0,count=0,centralSize=0;
  const stamp=((now.getHours()<<11)|(now.getMinutes()<<5)|(now.getSeconds()>>1));
  const date=((Math.max(1980,Math.min(2107,now.getFullYear()))-1980)<<9)|((now.getMonth()+1)<<5)|now.getDate();
  for await(const file of files){
    if(!(file.blob instanceof Blob))throw new Error('导出文件缺少数据。');
    const original=safeFileName(file.name),dot=original.lastIndexOf('.'),base=dot>0?original.slice(0,dot):original,ext=dot>0?original.slice(dot):'';
    let name=original,suffix=2;while(used.has(name.toLocaleLowerCase()))name=base+' ('+(suffix++)+')'+ext;
    const bytes=encoder.encode(name),size=file.blob.size;
    if(size>MAX32||bytes.length>65535||count>=65535||offset+30+bytes.length+size>MAX32)throw new Error('所选文件过多或超过 4 GB，请分批导出。');
    used.add(name.toLocaleLowerCase());
    const crc=await crc32(file.blob),header=new Uint8Array(30+bytes.length),view=new DataView(header.buffer);
    view.setUint32(0,0x04034b50,true);view.setUint16(4,20,true);view.setUint16(6,0x0800,true);
    view.setUint16(10,stamp,true);view.setUint16(12,date,true);view.setUint32(14,crc,true);
    view.setUint32(18,size,true);view.setUint32(22,size,true);view.setUint16(26,bytes.length,true);header.set(bytes,30);
    const entry=new Uint8Array(46+bytes.length),entryView=new DataView(entry.buffer);
    entryView.setUint32(0,0x02014b50,true);entryView.setUint16(4,20,true);entryView.setUint16(6,20,true);entryView.setUint16(8,0x0800,true);
    entryView.setUint16(12,stamp,true);entryView.setUint16(14,date,true);entryView.setUint32(16,crc,true);
    entryView.setUint32(20,size,true);entryView.setUint32(24,size,true);entryView.setUint16(28,bytes.length,true);entryView.setUint32(42,offset,true);entry.set(bytes,46);
    parts.push(header,file.blob);central.push(entry);centralSize+=entry.length;offset+=header.length+size;count++;
  }
  if(offset+centralSize+22>MAX32)throw new Error('所选文件超过 4 GB，请分批导出。');
  const end=new Uint8Array(22),view=new DataView(end.buffer);
  view.setUint32(0,0x06054b50,true);view.setUint16(8,count,true);view.setUint16(10,count,true);view.setUint32(12,centralSize,true);view.setUint32(16,offset,true);
  return new Blob([...parts,...central,end],{type:'application/zip'});
}
