import {env,pipeline} from './vendor/transformers.min.js';
env.allowRemoteModels=false;
env.allowLocalModels=true;
env.localModelPath=new URL('./models/browser/',import.meta.url).href;
env.useBrowserCache=false;
env.backends.onnx.wasm.wasmPaths=new URL('./vendor/',import.meta.url).href;
env.backends.onnx.wasm.numThreads=1;
env.backends.onnx.wasm.proxy=false;
let translator;

function chunks(text){
  if(translator.tokenizer(text).input_ids.data.length<=440)return [text];
  let middle=Math.floor(text.length/2),space=text.lastIndexOf(' ',middle);
  if(space>text.length/4)middle=space;
  return [...chunks(text.slice(0,middle).trim()),...chunks(text.slice(middle).trim())];
}
self.onmessage=async({data:{entries}})=>{
  try{
    postMessage({type:'status',label:'正在载入本地翻译模型…'});
    translator??=await pipeline('translation','opus-mt-en-zh',{device:'wasm',dtype:'q8'});
    for(let i=0;i<entries.length;i++){
      const entry=entries[i];postMessage({type:'status',label:`正在翻译 ${i+1} / ${entries.length} 句…`});
      const output=[];
      for(const part of chunks(entry.text)){
        // This multilingual Marian model requires a target-language token.
        const result=await translator('>>cmn_Hans<< '+part,{max_new_tokens:512,num_beams:1});
        const translated=result[0]?.translation_text?.trim();
        if(!translated)throw new Error('模型没有返回译文，请重试或手动填写。');
        output.push(translated);
      }
      postMessage({type:'sentence',index:entry.index,text:entry.text,translation:output.join(' ')});
    }
    postMessage({type:'done'});
  }catch(error){postMessage({type:'error',error:error.message});}
};
