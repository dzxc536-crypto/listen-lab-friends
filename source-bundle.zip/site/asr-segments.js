// Keep model text in order. Merge overlapping estimates instead of inventing times.
export function groupWords(words,duration){
  const out=[];let current=[];
  const finish=()=>{
    if(!current.length)return;
    let sentence={text:current.map(w=>w.word).join(' '),words:current,
      start:Math.max(0,Math.min(...current.map(w=>w.start))-.04),
      end:Math.min(duration,Math.max(...current.map(w=>w.end))+.08),alignment:'estimated'};
    if(current.some((w,i)=>i&&w.start<current[i-1].start-.001))sentence.alignment='partial';
    while(out.length){
      const previous=out.at(-1),previousEnd=Math.max(...previous.words.map(w=>w.end)),nextStart=Math.min(...sentence.words.map(w=>w.start));
      if(nextStart>=previousEnd-.001)break;
      out.pop();sentence={text:previous.text+' '+sentence.text,words:[...previous.words,...sentence.words],
        start:Math.min(previous.start,sentence.start),end:Math.max(previous.end,sentence.end),alignment:'partial'};
    }
    out.push(sentence);current=[];
  };
  const abbreviations=['mr.','mrs.','ms.','dr.','prof.','st.','etc.','e.g.','i.e.'];
  for(const original of words){
    const text=String(original.word??'').trim();
    if(!text||!Number.isFinite(original.start)||!Number.isFinite(original.end))continue;
    const w={word:text,start:Math.max(0,original.start),end:Math.min(duration,original.end)};
    if(w.end<=w.start)continue;
    if(current.length&&(w.start-current.at(-1).end>=.85||(w.start-current[0].start>18&&current.length>=14)))finish();
    current.push(w);const token=w.word.replace(/["”’)]+$/g,'');
    if(/[.!?]$/.test(token)&&!abbreviations.includes(token.toLowerCase()))finish();
  }
  finish();
  for(let i=0;i<out.length-1;i++)out[i].end=Math.min(out[i].end,out[i+1].start+.04);
  return out;
}
