import './app.js';
import {getManifest,getOfflineState,ensureRegistration,prepareResources} from './share-resources.js';
const $=s=>document.querySelector(s),dialog=$('#share-dialog');
const megabytes=n=>(n/1000000).toFixed(1)+' MB';
let downloading=false;
async function status(){
  const state=await getOfflineState();
  const label=state.ready?'模型已保存，可以在本设备上识别和翻译。':state.available?'第一次使用请下载模型；已有字幕的音频可直接练习。':'请使用 HTTPS 网址打开此网页。';
  $('#share-status').textContent=label;
  $('#share-download').textContent=state.ready?'检查并补齐离线资源':'下载并保存模型';
  $('#share-download').disabled=!state.available||downloading;
  $('#share-launch-state').textContent=state.ready?'模型已保存':'首次使用需准备模型';
  return state;
}
document.addEventListener('listen-resources-progress',({detail:d})=>{
  if(d.state==='progress'){
    $('#share-progress').hidden=false;
    $('#share-progress').value=d.totalBytes?Math.min(100,100*d.completedBytes/d.totalBytes):0;
    const label=`已准备 ${megabytes(d.completedBytes)} / ${megabytes(d.totalBytes)} · ${d.completed} / ${d.total} 个文件`;
    $('#share-status').textContent=label;$('#offline-state').textContent=label;
  }
});
$('#share-download').onclick=async()=>{
  if(downloading)return;downloading=true;$('#share-download').disabled=true;$('#share-error').textContent='';
  try{
    await prepareResources();$('#share-progress').value=100;
    $('#offline-state').textContent='应用和全部模型已保存。请在本设备断网后验证。';
    await status();$('#share-status').textContent='准备完成！可以导入英语音频，也可以先试一段演示。';
  }catch(e){$('#share-error').textContent=e.message;$('#share-download').textContent='重试并继续下载';}
  finally{downloading=false;$('#share-download').disabled=false;}
};
$('#share-open').onclick=async()=>{try{await status();}catch(e){$('#share-error').textContent=e.message;}dialog.showModal();};
$('#share-close').onclick=()=>{localStorage.setItem('listen-share-welcome','seen');dialog.close();};
$('#share-demo').onclick=()=>{localStorage.setItem('listen-share-welcome','seen');dialog.close();document.dispatchEvent(new Event('listen-share-demo'));};
$('#share-copy').onclick=async()=>{
  const url=new URL('./',import.meta.url).href;$('#share-url').value=url;
  try{await navigator.clipboard.writeText(url);$('#share-copy-state').textContent='链接已复制，可以发送给好友。';}
  catch{$('#share-url').focus();$('#share-url').select();$('#share-copy-state').textContent='请复制上方网址，发送给好友。';}
};
$('#share-url').value=new URL('./',import.meta.url).href;
window.addEventListener('beforeunload',e=>{if(downloading){e.preventDefault();e.returnValue='';}});
try{
  const manifest=await getManifest();$('#share-size').textContent=`完整离线资源约 ${megabytes(manifest.totalBytes)}。下载只需准备一次，清理站点数据或资源更新后可能需要重新下载。`;
  try{await ensureRegistration();}catch(e){$('#share-error').textContent=e.message;}
  await status();
  if(!localStorage.getItem('listen-share-welcome'))dialog.showModal();
}catch(e){$('#share-error').textContent=e.message;dialog.showModal();}
