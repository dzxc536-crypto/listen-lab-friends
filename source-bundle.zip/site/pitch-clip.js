import {processOffline} from './vendor/soundtouch/processOffline.js';
import {wavClip} from './storage.js';
export async function pitchClip(pcm,start,end,rate){
  const a=Math.floor(Math.max(0,start)*16000),b=Math.min(pcm.length,Math.ceil(end*16000));
  if(b<=a)throw new Error('播放区间为空。');
  if((b-a)/rate>16000*60*60)throw new Error('极慢速播放区间过长，请开启句末暂停后逐句播放。');
  const input=new AudioBuffer({numberOfChannels:1,length:b-a,sampleRate:16000});
  input.copyToChannel(pcm.subarray(a,b),0);
  const output=await processOffline({input,processorUrl:'./vendor/soundtouch/soundtouch-processor.js',playbackRate:rate,pitch:1});
  return wavClip(output.getChannelData(0),0,output.duration,1);
}
