import {env,pipeline,AutoProcessor,AutoModelForCTC} from './vendor/transformers.min.js';
import {groupWords as groups} from './asr-segments.js';
env.allowRemoteModels=false;
env.allowLocalModels=true;
env.localModelPath=new URL('./models/browser/',import.meta.url).href;
env.useBrowserCache=false;
env.backends.onnx.wasm.wasmPaths=new URL('./vendor/',import.meta.url).href;
let runtimeThreads=1;
function configureRuntime(mode){
  const cores=Number(navigator.hardwareConcurrency)||2;
  const memoryLimit=/Android|iPhone|iPad/i.test(navigator.userAgent)||(navigator.deviceMemory&&navigator.deviceMemory<4)?2:4;
  runtimeThreads=mode==='compatible'||!self.crossOriginIsolated||typeof SharedArrayBuffer==='undefined'?1:Math.min(memoryLimit,Math.max(1,Math.floor(cores/2)));
  env.backends.onnx.wasm.numThreads=runtimeThreads;
  env.backends.onnx.wasm.initTimeout=15000;
}
env.backends.onnx.wasm.proxy=false;
let recognizer,aligner,processor,vocab;
const progress=(id,text)=>(event)=>{if(Number.isFinite(event.progress))postMessage({id,type:'progress',label:text,progress:Math.round(event.progress*.15)});};

async function transcribe(pcm,id){
  if(!recognizer){
    try{recognizer=await pipeline('automatic-speech-recognition','whisper-tiny.en',{device:'wasm',dtype:'q8',progress_callback:progress(id,'载入本设备识别模型')});}
    catch(error){error.retryCompatible=runtimeThreads>1;throw error;}
  }
  const chunk=25,stride=4,total=Math.max(1,Math.ceil((pcm.length-chunk*16000)/((chunk-2*stride)*16000))+1),model=recognizer.model,generate=model.generate;let completed=0;
  const modeLabel=runtimeThreads>1?'并行加速':'兼容识别';
  postMessage({id,type:'progress',label:`${modeLabel} · 识别第 1 / ${total} 段`,progress:20,threads:runtimeThreads});
  model.generate=async function(...args){
    postMessage({id,type:'progress',label:`${modeLabel} · 识别第 ${completed+1} / ${total} 段`,progress:20+Math.floor(completed/total*75),threads:runtimeThreads});
    const value=await generate.apply(this,args);completed++;
    postMessage({id,type:'progress',label:`${modeLabel} · 已识别 ${completed} / ${total} 段`,progress:20+Math.floor(completed/total*75),threads:runtimeThreads});
    return value;
  };
  let result;
  try{result=await recognizer(pcm,{return_timestamps:'word',chunk_length_s:chunk,stride_length_s:stride});}
  finally{model.generate=generate;}
  postMessage({id,type:'progress',label:'整理字幕时间边界',progress:97});
  const words=(result.chunks||[]).map(c=>({word:c.text.trim(),start:c.timestamp?.[0],end:c.timestamp?.[1]}));
  const sentences=groups(words,pcm.length/16000);
  if(!sentences.length)throw new Error('模型没有返回可用的单词定位；没有伪造时间。可导入带时间字幕，或检查音频。');
  return sentences;
}

function ctcWords(logits,pcmLength,text,offset){
  const [batch,frames,size]=logits.dims;
  if(batch!==1)throw new Error('对齐模型输出无效');
  const blank=aligner.config.pad_token_id??0,words=text.trim().split(/\s+/),tokens=[],owners=[];
  words.forEach((word,wi)=>{
    const chars=[...word.toUpperCase()].filter(c=>vocab[c]!==undefined&&c!=='|');
    if(chars.length){if(tokens.length){tokens.push(vocab['|']);owners.push(-1);}for(const c of chars){tokens.push(vocab[c]);owners.push(wi);}}
  });
  if(!tokens.length)throw new Error('原文没有模型可对齐的英语字符。');
  const states=tokens.length*2+1;
  if(states*frames>24_000_000)throw new Error('此段原文对齐需要过多内存，请导入带时间字幕，或先在电脑上分句对齐。');
  const labels=new Int32Array(states);labels.fill(blank);tokens.forEach((v,i)=>labels[i*2+1]=v);
  const path=new Uint8Array(states*frames);let prev=new Float32Array(states),next=new Float32Array(states);prev.fill(-Infinity);
  prev[0]=logits.data[blank];prev[1]=logits.data[tokens[0]];
  for(let t=1;t<frames;t++){
    for(let s=0;s<states;s++){
      let best=prev[s],step=0;
      if(s>0&&prev[s-1]>best){best=prev[s-1];step=1;}
      if(s>1&&labels[s]!==blank&&labels[s]!==labels[s-2]&&prev[s-2]>best){best=prev[s-2];step=2;}
      next[s]=best+logits.data[t*size+labels[s]];path[t*states+s]=step;
    }
    [prev,next]=[next,prev];
  }
  let state=prev[states-1]>prev[states-2]?states-1:states-2;
  if(!Number.isFinite(prev[state]))throw new Error('音频区间太短，无法对齐这段原文。');
  const first=new Int32Array(words.length),last=new Int32Array(words.length);first.fill(frames);last.fill(-1);
  for(let t=frames-1;t>=0;t--){
    if(state%2){const owner=owners[(state-1)/2];if(owner>=0){first[owner]=Math.min(first[owner],t);last[owner]=Math.max(last[owner],t);}}
    if(t>0)state-=path[t*states+state];
  }
  const frameSeconds=pcmLength/16000/frames;
  return words.map((word,i)=>({word,...(last[i]>=0?{start:offset+first[i]*frameSeconds,end:offset+(last[i]+1)*frameSeconds}:{})}));
}

async function align(pcm,sentences,id,deriveBounds){
  if(!aligner){
    processor=await AutoProcessor.from_pretrained('wav2vec2-base-960h');
    aligner=await AutoModelForCTC.from_pretrained('wav2vec2-base-960h',{device:'wasm',dtype:'q8',progress_callback:progress(id,'载入本设备文字对齐模型')});
    vocab=await (await fetch('./models/browser/wav2vec2-base-960h/vocab.json')).json();
  }
  const results=[];
  for(let i=0;i<sentences.length;i++){
    const s=sentences[i];postMessage({id,type:'progress',label:`对齐第 ${i+1} / ${sentences.length} 句`,progress:Math.round(i/sentences.length*100)});
    const samples=pcm.subarray(Math.floor(s.start*16000),Math.ceil(s.end*16000));
    const inputs=await processor(samples),output=await aligner(inputs);
    const words=ctcWords(output.logits,samples.length,s.text,s.start);
    if(deriveBounds)results.push(...groups(words,pcm.length/16000));
    else results.push({...s,words,alignment:words.every(w=>Number.isFinite(w.start))?'aligned':'partial'});
  }
  return results;
}
self.onmessage=async event=>{
  const {id,type,pcm,sentences,deriveBounds,performanceMode='auto'}=event.data;
  if(!recognizer&&!aligner)configureRuntime(performanceMode);
  try{const result=type==='transcribe'?await transcribe(pcm,id):await align(pcm,sentences,id,deriveBounds);postMessage({id,type:'done',sentences:result});}
  catch(e){postMessage({id,type:'error',error:e.message,retryCompatible:runtimeThreads>1&&(e.retryCompatible||/wasm|thread|memory|worker|backend|allocation/i.test(e.message))});}
};
