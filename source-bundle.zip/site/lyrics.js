// The sweep follows sentence time, independent of model-estimated word times.
export function prepareLyrics(button){
  for(const node of [...button.childNodes]){
    if(node.nodeType===Node.TEXT_NODE){
      const pieces=document.createDocumentFragment();
      for(const part of node.textContent.split(/(\s+)/)){
        if(!part)continue;
        if(/^\s+$/.test(part))pieces.append(document.createTextNode(part));
        else{const span=document.createElement('span');span.className='lyric-fragment';span.textContent=part;pieces.append(span);}
      }
      node.replaceWith(pieces);
    }else if(node.nodeType===Node.ELEMENT_NODE)node.classList.add('lyric-fragment');
  }
  button._lyricSegments=null;
}
export function paintLyrics(button,progress){
  if(!button)return;
  if(!button._lyricSegments){
    let total=0;const segments=[];
    for(const node of button.childNodes){
      const range=document.createRange();range.selectNodeContents(node);
      const width=[...range.getClientRects()].reduce((sum,r)=>sum+r.width,0);
      if(node.nodeType===Node.ELEMENT_NODE)segments.push({node,start:total,width});
      total+=width;
    }
    button._lyricSegments={segments,total};
  }
  const {segments,total}=button._lyricSegments;
  const edge=Math.max(0,Math.min(1,progress))*total;
  button.dataset.sentenceProgress=String(progress);
  for(const {node,start,width} of segments){
    const percent=Math.max(0,Math.min(100,(edge-start)/Math.max(width,.01)*100));
    node.style.setProperty('--lyric-fill',percent+'%');node.dataset.lyricFill=String(percent);
    const paint=percent===0?'linear-gradient(var(--text),var(--text))':percent===100?'linear-gradient(var(--lyric-color),var(--lyric-color))':`linear-gradient(90deg,var(--lyric-color) ${Math.max(0,percent-4)}%,var(--text) ${Math.min(100,percent+4)}%)`;
    node.style.setProperty('--lyric-paint',paint);
  }
}
